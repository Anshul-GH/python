import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool import server, session, blu, cache, CACHE_TIMEOUT
from SupplyChainReportingTool import diff_month, add_months, month_tick_formater, month_filter
from SupplyChainReportingTool.app_supplier.app import app_vndr, list_to_options, vndr_list_all, custom_vndr_groups, clean_vndr_list


compare_metrics = {
    'fulfillment': 'Curr Due Fulfillment Rate',
    'dropins': 'Drop-Ins',
    'stability': 'EDI Stability'
}

layout_vndr_compare = [
    dcc.Dropdown(
        id='metric_list',
        options=[
            {'label': l, 'value': v}
            for v, l in compare_metrics.items()
        ],
        value='stability'
    ),
    html.Span(
        style={'width': '5ch', 'display': 'inline-block'}
    ),
    html.Div(
        style={'display': 'inline-block'},
        children=[
            dcc.Dropdown( # Vendor list
                id='vndr_list_prim',
                options=list_to_options(vndr_list_all()),
                placeholder='Vendor ID'
            ),
            html.Span(
                ' vs ',
                style={'vertical-align': 'middle'}
            ),
            dcc.Dropdown( # Vendor list
                id='vndr_list_scnd',
                options=list_to_options(['(all)']) + custom_vndr_groups() + list_to_options(vndr_list_all()),
                placeholder='Vendor IDs',
                multi=True
            )
        ]
    ),
    dcc.Graph(
        id='compare-chart',
        figure={
            'layout': go.Layout(
                yaxis=dict(title='percent', range=[0, 1], fixedrange=True, side='right', zeroline=False, showgrid=False)
            ),
            'data': [go.Scatter(x=[], y=[], name='Data', mode='lines+markers')]
        }
    ),
    html.Br(),
    html.A(
        'Download data',
        id='vndrcomp_dl_data',
        href='/dl/',
        className='btn'
    ),
]


def fetch_transform_vndrcomp_data(sql, sql_args):
    df = blu.fetch(sql, sql_args)
    df['DATE'] = df.DATE - pd.offsets.MonthBegin(1)
    
    return df


def vndrcomp_clean_pivot(df, prim_vndr, min_num_vndrs):
    dates = df[['VNDR_ID', 'DATE']].groupby(by=['DATE']).count().reset_index(level=0)
    df = df.loc[df.DATE >= dates.loc[dates.VNDR_ID > 0.25 * min_num_vndrs].DATE.min()]
    
    df_selection = df.pivot(index='VNDR_ID', columns='DATE', values='DATA')
    
    df_indv = df.loc[df.VNDR_ID == prim_vndr, ['DATA', 'DATE']].sort_values(by='DATE')
    
    return df_selection, df_indv


@cache.memoize(timeout=CACHE_TIMEOUT)
def format_vndrcomp_sql(sql, vndr_list):
    if vndr_list is not None and len(vndr_list) > 0 and '(all)' not in vndr_list:
        sql = sql.format(
            'and (\n\t{}\n)'.format(
                'VNDR_ID in ({})'.format(','.join(['?' for _ in vndr_list]))
            )
        )
        
        sql_args = vndr_list
    else:
        sql = sql.format('')
        sql_args = []
    
    return sql, sql_args


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_dropins(vndr_list):
    sql = """
select 
    trim(B ' ' from VNDR_ID) as VNDR_ID, 
    END_OF_MONTH as DATE, 
    sum(DROP_IN_LT_0_ORDERS + 
        DROP_IN_0_2_ORDERS + 
        DROP_IN_2_10_ORDERS) / (1.0 * sum(TOTAL_ORDERS)) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_DROP_INS
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_edistab(vndr_list):
    sql = """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    END_OF_MONTH as DATE,
    sum(ORDER_EDI_INSTABILITY_POSITIVE_ONLY_X_UNIT_PRICE) / sum(CUR_UNIT_PRICE) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_EDI_STABILITY
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_currfulfill(vndr_list):
    sql = """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    END_OF_MONTH as DATE,
    sum(FULFILLED_QTY_CURR_DUE) / sum(REQ_QTY_CURR_DUE) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_FULFILLMENT_RATE
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))

def fetch_vndr_compare_pivot(metric, prim_vndr, vndr_list):
    if vndr_list is not None and len(vndr_list) > 0 and '(all)' not in vndr_list:
        vndr_list += [prim_vndr]
        gids = [x for x in vndr_list if x.isdigit()]
        if len(gids) > 0:
            group_vndrs = blu.fetch("""
select distinct trim(B ' ' from VNDR_ID) as VNDR_ID
from SSZ_MATFLO.VNDR_GROUP_MEMBERS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUPS where IS_ACTIVE = 1)
and GID in ({})
            """.format(','.join(['?' for _ in gids])),
            gids)
            vndr_list = [x for x in vndr_list if x not in gids] + group_vndrs.VNDR_ID.tolist()
        
        min_num_vndrs = len(set(vndr_list))
    else:
        gids = []
        group_vndrs = None
        vndr_list = ['(all)']
        min_num_vndrs = 300
    
    vndr_list = sorted(set(vndr_list))
    server.logger.info('{} expands to {}'.format(gids, list(group_vndrs.VNDR_ID) if group_vndrs is not None else []))
    if metric == 'dropins':
        df = fetch_vndrcomp_dropins(vndr_list)
    elif metric == 'fulfillment':
        df = fetch_vndrcomp_currfulfill(vndr_list)
    else:
        df = fetch_vndrcomp_edistab(vndr_list)
    
    df_selection, df = vndrcomp_clean_pivot(df, prim_vndr, min_num_vndrs)
#    dates = df[['VNDR_ID', 'DATE']].groupby(by=['DATE']).count().reset_index(level=0)
#    df = df.loc[df.DATE >= dates.loc[dates.VNDR_ID > 0.25 * min_num_vndrs].DATE.min()]
    
#    df_selection = df.pivot(index='VNDR_ID', columns='DATE', values='DATA')
    x_sel = []
    y_sel = []
    for col in df_selection.columns:
        y_to_add = list(df_selection[col])
        x_sel += [col for _ in range(len(y_to_add))]
        y_sel += y_to_add
        
#    df = df.loc[df.VNDR_ID == prim_vndr, ['DATA', 'DATE']].sort_values(by='DATE')
    x_prim = list(df['DATE'])
    y_prim = list(df['DATA'])
    
    return x_sel, y_sel, x_prim, y_prim


@app_vndr.callback(
    dash.dependencies.Output('vndrcomp_dl_data', 'href'),
    [dash.dependencies.Input('metric_list', 'value'),
     dash.dependencies.Input('vndr_list_prim', 'value'),
     dash.dependencies.Input('vndr_list_scnd', 'value')]
)
def update_dl_url(metric, prim_vndr, scnd_vndr):
    url = '/dl/vndr_comp/{}/?vndr={}&vndr_list={}'.format(metric, prim_vndr, ','.join(scnd_vndr) if scnd_vndr else None)
    server.logger.info('updated url to \n\t\'{}\''.format(url))
    return url


@app_vndr.callback(
    dash.dependencies.Output('compare-chart', 'figure'),
    [dash.dependencies.Input('metric_list', 'value'),
     dash.dependencies.Input('vndr_list_prim', 'value'),
     dash.dependencies.Input('vndr_list_scnd', 'value')]
)
def populate_compare_chart(metric, prim_vndr, scnd_vndr):
    server.logger.info("populating chart with \n\tmetric='{}'\n\tprim_vndr='{}'\n\tscnd_vndr='{}'\n\n".format(
        metric,
        prim_vndr,
        scnd_vndr)
    )
    
    if prim_vndr is None or scnd_vndr is None or len(scnd_vndr) == 0:
        data = [go.Scatter(x=[], y=[], name='Data', mode='lines+markers')]
    else:
        x_sel, y_sel, x_prim, y_prim = fetch_vndr_compare_pivot(metric, prim_vndr, [x for x in scnd_vndr if x])
        data = [
            go.Box(
                y=y_sel,
                x=x_sel,
                name='Supply Base' if '(all)' in scnd_vndr else 'Selected Vendors',
                boxpoints='outliers'
            ),
            go.Scatter(
                x=x_prim,
                y=y_prim,
                name=prim_vndr
            )
        ]
    
    return {
        'layout': go.Layout(
            title=compare_metrics[metric],
            yaxis=dict(
                title='percent',
                range=[0, 1],
                fixedrange=True,
                side='left',
                zeroline=True,
                showgrid=True
            ),
            xaxis=dict(
                dtick='M1'
            )
        ),
        'data': data
    }


@server.route('/dl/vndr_comp/<string:metric>/')
def dl_vndr_comp(metric):
    prim_vndr = request.args.get('vndr').upper()
    vndr_list = request.args.get('vndr_list').replace(' ', '').upper().split(',')
    vndr_list = clean_vndr_list(prim_vndr, vndr_list)

    if metric == 'fulfillment':
        df = fetch_vndrcomp_currfulfill(vndr_list)
    elif metric == 'stability':
        df = fetch_vndrcomp_edistab(vndr_list)
    elif metric == 'dropins':
        df = fetch_vndrcomp_dropins(vndr_list)
    else:
        df = None
    
    df.sort_values(by=['DATE', 'VNDR_ID'], inplace=True)
    
    df_selection, df = vndrcomp_clean_pivot(df, prim_vndr, 1)
    df = df.rename(columns={'DATA': metric})
    
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    wb = writer.book
    frmt_date = wb.add_format({'num_format': 'mmm-yyy'})
    
    df.to_excel(writer, index=False, sheet_name=prim_vndr, columns=['DATE', metric])    
    ws_vndr = writer.sheets[prim_vndr]
    ws_vndr.set_column('A:A', 18, frmt_date)
    
    df_selection.to_excel(writer, index=True, sheet_name='Selected Vendors')
    ws_grup = writer.sheets['Selected Vendors']

    writer.save()
    writer.close()
    output.seek(0)
    
    return send_file(output, attachment_filename=metric+'.xlsx', as_attachment=True)