import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool import server, blu, cache, CACHE_TIMEOUT
from SupplyChainReportingTool.app_supplier.app import \
    app_vndr, \
    vndr_list_all, \
    custom_vndr_groups, \
    list_to_options, \
    clean_vndr_list


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_data(metric: str, vndr_group: list, date_from: str, date_to: str) -> pd.DataFrame:
    """Fetches data for given metric, vendor group, and date range.
    
    :param metric: Metric short name. Acceptable values are 'pastdue', 'stability', 'dropins', fulfillment'.
    :param vndr_group: List of vendors for which the specified metric will be pulled.
    :param date_from: Start of date range. Value must be usable by db2. String or datetime object are OK.
    :param date_to: End of date range. Value must be usable by db2. String or datetime object are OK.
    :returns: DataFrame containing metric data for the specified vendors and date range.
    :raises: KeyError if metric parameter specifies a non-implemented metric.
    """
    sql = {
        'pastdue': """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    (0.0 + sum(HAS_PAST_DUE)) / sum(TOTAL) as DATA,
    count(1) as C
from ML_PREDICT_SR.VENDOR_REPORT_PAST_DUES
where
    CAL_DATE between ? and ?
    {}
group by VNDR_ID
having 
    sum(TOTAL) > 0
""",
        'stability': """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    sum(ORDER_EDI_INSTABILITY_POSITIVE_ONLY) / sum(ROW_COUNT) as DATA,
    count(1) as C
from ML_PREDICT_SR.VENDOR_REPORT_EDI_STABILITY
where
    REQ_DATE between ? and ?
    {}
group by VNDR_ID
having 
    sum(ROW_COUNT) > 0
""",
        'dropins': """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    (0.0 + sum(TOTAL_ORDERS) - sum(NOT_DROPIN)) / sum(TOTAL_ORDERS) as DATA,
    count(1) as C
from ML_PREDICT_SR.VENDOR_REPORT_DROP_INS
where
    REQ_DATE between ? and ?
    {}
group by VNDR_ID
having 
    sum(TOTAL_ORDERS) > 0
""",
        'fulfillment': """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    sum(FULFILLED_QTY_CURR_DUE) / sum(REQ_QTY_CURR_DUE) as DATA,
    count(1) as C
from ML_PREDICT_SR.VENDOR_REPORT_FULFILLMENT_RATE
where
    CAL_DATE between ? and ?
    {}
group by VNDR_ID
having 
    sum(REQ_QTY_CURR_DUE) > 0
"""
    }.get(metric)
    
    if sql is None:
        raise KeyError("'{}' metric not implmented".format(metric))
    
    sql = sql.format(
        'and VNDR_ID in ({})'.format(','.join('?' for _ in vndr_group)) if '(all)' not in vndr_group else ''
    )
    
    return blu.fetch(sql, [date_from, date_to] + (vndr_group if '(all)' not in vndr_group else []))

compare_metrics = {
    'fulfillment': 'Fulfillment Rate: Curr Due',
    'dropins': 'Drop-Ins % of Total Orders',
    'stability': 'EDI Stability',
    'pastdue': 'Past-Due % of Total Orders'
}

figure_layout = dict(
    width=750,
    height=750,
    yaxis=dict(range=[-0.01, 1.01], fixedrange=True, side='left', zeroline=True, showgrid=True),
    xaxis=dict(range=[-0.01, 1.01], side='left', zeroline=True, showgrid=True),
    hovermode='closest',
    margin={'l': 50, 'r': 40, 't': 40, 'b': 50}
)
layout_metric_compare = [
    html.Div(  # y-axis metric
        [
        html.Label('Y-axis metric: '),
        dcc.Dropdown(
            id='mvm_metric_y',
            options=[
                {'label': l, 'value': v}
                for v, l in compare_metrics.items()
            ]
        )],
        style={'display': 'inline-block'}
    ),
    html.Div(  # x-axis metric
        [
        html.Label('X-axis metric: '),
        dcc.Dropdown(
            id='mvm_metric_x',
            options=[
                {'label': l, 'value': v}
                for v, l in compare_metrics.items()
            ]
        )],
        style={'display': 'inline-block'}
    ),
    html.Div(  # vendor group
        [
        html.Label('Vendor Group'),
        dcc.Dropdown(
            id='mvm_vndr_group',
            placeholder='Vendor IDs',
            options=list_to_options(['(all)']) + custom_vndr_groups() + list_to_options(vndr_list_all()),
            multi=True
        )],
        style={'display': 'inline-block'}
    ),
    dcc.Graph(
        id='mvm_graph',
        figure={
            'layout': figure_layout,
            'data': [go.Scatter(x=[], y=[], name='Data', mode='markers')]
        },
        config={
            'modeBarButtonsToRemove': [
                'pan2d', 
                'select2d', 
                'lasso2d', 
                'toggleSpikelines', 
                'hoverCompareCartesian', 
                'hoverClosestCartesian',
                'zoom2d',
                'zoomIn2d',
                'zoomOut2d',
                'autoScale2d'
            ]
        }
    ),
    html.Div(
        id='mvm_vndr_expando',
        style={'margin-top': '10px'}
    )
]


@app_vndr.callback(
    dash.dependencies.Output('mvm_metric_x', 'options'),
    [dash.dependencies.Input('mvm_metric_y', 'value')]
)
def update_x_list(val_picked):
    """Callback function to update the x-axis list metrics when a y-metric is chosen."""
    return [
        {'label': l, 'value': v}
        for v, l in compare_metrics.items()
        if v != val_picked
    ]


@app_vndr.callback(
    dash.dependencies.Output('mvm_vndr_expando', 'children'),
    [dash.dependencies.Input('mvm_vndr_group', 'value'), ]
)
def display_vndr_list(vndr_group):
    """Callback function to populate the vendor list display (mostly to clarify when a custom group is picked)."""
    if vndr_group:
        return """
    Vendor groups selection expands to {}
    """.format(', '.join(clean_vndr_list(None, vndr_group)))
    else:
        return None


@app_vndr.callback(
    dash.dependencies.Output('mvm_graph', 'figure'),
    [dash.dependencies.Input('mvm_metric_x', 'value'),
     dash.dependencies.Input('mvm_metric_y', 'value'),
     dash.dependencies.Input('mvm_vndr_group', 'value')]
)
def update_metric_v_metric_chart(m_x: str, m_y: str, vndr_group: list) -> go.Figure:
    """Callback to update metric v metric chart.

    :param m_x:
    """
    server.logger.info('User viewing x={}, y={} for vndrs: {}'.format(m_x, m_y, vndr_group))
    layout = {**figure_layout}
    layout['xaxis']['title'] = compare_metrics.get(m_x)
    layout['yaxis']['title'] = compare_metrics.get(m_y)
    
    if not (m_x and m_y and vndr_group):
        data = []
    else:
        vndr_group = clean_vndr_list(None, vndr_group)
        server.logger.info('Expanded vendor list: {}'.format(vndr_group))
        
        values = fetch_data(m_x, vndr_group, '2018-01-01', '2018-05-31').rename(columns={'DATA': 'DATA_X', 'C': 'C_X'})
        values = values.merge(
            fetch_data(m_y, vndr_group, '2018-04-01', '2018-04-30').rename(columns={'DATA': 'DATA_Y', 'C': 'C_Y'}),
            on='VNDR_ID'
        )
        values.C = values.C_X  # values[['C_X', 'C_Y']].max(axis=1)
        values.S = 8 + 6 * values.C / values.C.max()

        data = [go.Scatter(
            x=list(values.DATA_X),
            y=list(values.DATA_Y),
            text=list(values.VNDR_ID),
            name='Data',
            mode='markers',
            marker=dict(
                color=values.C,
                size=values.S,
                showscale=True,
                # colorscale=[[0.0, 'hsl(300, 100, 25)'], [1.0, 'hsl(360, 100, 50)']]
                colorscale=[[0.0, 'hsl(360, 100, 10)'], [1.0, 'hsl(360, 100, 50)']]
            )
        )]
        
    return go.Figure(layout=figure_layout, data=data)
