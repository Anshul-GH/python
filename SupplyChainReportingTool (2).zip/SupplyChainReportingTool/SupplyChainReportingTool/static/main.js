function populateItems(item, loc, date) {
    
    console.log("Populating ITEM_NOs");
    
    d3.json('/item_nos/', function(data) {
        console.log("processing response");
        var itemList = user_item_nos.concat(data.ITEM_NOs);
        
        var options = d3.select('#item_no');
        options.selectAll('option').remove();
        options.selectAll('option').data(itemList).enter().append('option')
            .attr('value', function (d) { return d; })
            .text(function (d) { return d; });
            
        if (item) {
            options.property('value', item);
        }
        
        selected_item_no = options.property('value');
            
        populateLocs(loc, date);
    })
}

function populateLocs(loc, date) {
    var item_no = d3.select('#item_no').property('value');
    
    console.log("Populating LOCs for '" + item_no + "'");
    
    d3.json('/locs_for/'+item_no+'/', function(data){
        locList = data.LOCs;
            
        var options = d3.select('#loc');
        options.selectAll('option').remove();
        options.selectAll('option').data(locList).enter().append('option')
            .attr('value', function (d) { return d; })
            .text(function (d) { return d; });
            
        if (loc) {
            options.property('value', loc);
        }
        
        selected_loc = options.property('value');
        
        populateDates(date);
    })
}

function populateDates(date) {
    var item_no = d3.select('#item_no').property('value');
    var loc = d3.select('#loc').property('value');
    
    console.log("Populating REQ_DATEs for '" + item_no + "' at '" + loc + "'");
    
    d3.json('/dates_for/'+item_no+'/'+loc+'/', function(data) {
        dateList = data.REQ_DATEs;
        
        var options = d3.select('#req_date');
        options.selectAll('option').remove()
        options.selectAll('option').data(dateList).enter().append('option')
            .attr('value', function (d) { return d; })
            .text(function (d) { return d; });
            
        if (date) {
            options.property('value', date);
        }        
                
        selected_date = options.property('value');
    })
}


window.onload = function() {
    console.log("window loaded");

    d3.select('#item_no').on('change', function() {
        console.log("changed item_no selection");
        selected_item_no = this.value;
        populateLocs();
    });

    d3.select('#loc').on('change', function() {
        console.log("changed loc selection");
        selected_loc = this.value;
        populateDates();
    });
    
    d3.select('#req_date').on('change', function() {
        console.log("changed date selection");
        selected_date = this.value;
    });
    
    d3.selectAll('#data_source>label').on('click', function() {
        d3.select("#" + d3.select(this).attr('for'))
            .property('checked', true)
            .dispatch('change');
    });
    
    d3.selectAll('#data_source>label>input[name=formula_family]').on('change', function() {
        d3.select('#formula_family').property('value', d3.select(this).property('value'));
    });
    
    d3.selectAll('table.dataframe tbody td')
        .filter(function() {
            return (d3.select(this).text() == 'NaN' || 
                    d3.select(this).text() == 'None' ||
                    d3.select(this).text() == 'NaT');
        })
        .text('');
        
    d3.select('button#add_item').on('click', function() {
        input_dialog("Add ITEM_NO", new_item_no_validate);
    });
}

function new_item_no_validate(item_no) {
    d3.json('/validate_item_no/'+item_no+'/', function(data) {
        if (data.is_ITEM_NO) {
            user_item_nos.unshift(item_no);
            console.log(user_item_nos);
            
            var select_items = d3.select("select#item_no");
            
            var new_item = select_items.insert("option", ":first-child");
            new_item.property("value", item_no)
                    .text(item_no);
                    
            select_items.property("value", item_no).dispatch("change");
            
                    
            d3.select("input#user_item_nos").property("value", user_item_nos);
        }
        else {
            alert("'"+item_no+"' is not a valid ITEM_NO");
        }
    });
}
function new_item_no_append(item_no) {
}

function input_dialog(message, yesCallback, noCallback) {
    var overlay_div = d3.select('div#overlay');
    var input_div = d3.select('div#input');
    var input_entry = d3.select('div#input input#input_value');
    var input_OK = d3.select('div#input button#input_OK');
    var input_cancel = d3.select('div#input button#input_cancel');
    
    input_entry.on('keydown', function(){
        if (d3.event.key == 'Enter') {
            input_OK.dispatch('click');
        }
        if (d3.event.key == 'Escape') {
            input_cancel.dispatch('click')
        }
    });
    
    d3.select('div#input label').property('innerHTML', message);
    input_entry.property('value', '');
    
    overlay_div.style('display', 'initial');
    input_div.style('display', 'initial');
    
    input_cancel.on('click', function() {
        input_entry.property('value', '');
        
        overlay_div.style('display', 'none');
        input_div.style('display', 'none');
        
        if (noCallback) {
            noCallback();
        }
    });
    input_OK.on('click', function() {
        var val = input_entry.property('value');
        input_entry.property('value', '');
        
        overlay_div.style('display', 'none');
        input_div.style('display', 'none');
        
        yesCallback(val);
    });
}

function download_order_summary() {
    var url = "/instability/excel/order_summary/?"+
                        "item="+selected_item_no+"&"+
                        "loc="+selected_loc+"&"+
                        "date="+selected_date;
                        
    window.location = url;
}
function download_EDIs() {
    var url = "/instability/excel/EDIs/?"+
                        "item="+selected_item_no+"&"+
                        "loc="+selected_loc+"&"+
                        "date="+selected_date;
                        
    window.location = url;
}
function download_EDI_changes() {
    var url = "/instability/excel/EDIchanges/?"+
                        "item="+selected_item_no+"&"+
                        "loc="+selected_loc+"&"+
                        "date="+selected_date;
                        
    window.location = url;
}