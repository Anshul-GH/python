import dash
import dash_core_components as dcc
import dash_html_components as html

from SupplyChainReportingTool import blu
from SupplyChainReportingTool.app_supplier.app import app_vndr


def fetch_group_list():
    """Fetch list of groups, return list formatted for dropdown options."""
    df = blu.fetch("""
select
    GID, VNDR_GROUP_NAME
from SSZ_MATFLO.VNDR_GROUPS
order by VNDR_GROUP_NAME
""", [])

    return [{'label': r.get('VNDR_GROUP_NAME'), 'value': r.get('GID')}
            for r in df.to_dict(orient='records')]


def fetch_vndr_list(gid):
    """Fetch vendor list.  Return list of vendors."""
    if gid:
        df = blu.fetch("""
select
    VNDR_ID
from SSZ_MATFLO.VNDR_GROUP_MEMBERS
where
    GID = ?
order by VNDR_ID
    """, "%s" % gid)
        return list(df.VNDR_ID)
    else:
        return []


def fetch_group_info(gid):
    """Fetch infor about a group.  Return results as a dict."""
    df = blu.fetch("""
select
    *
from SSZ_MATFLO.VNDR_GROUPS
where
    GID = ?
""", '%s' % gid)
    df.IS_ACTIVE = df.IS_ACTIVE.apply(lambda x: 'Y' if 1 else 'N')
    return df.iloc[0]

layout_vndr_groups = [
    html.Div(  # y-axis metric
        [
            html.Label('Vendor Group: '),
            dcc.Dropdown(
                id='vgl_groups',
                options=fetch_group_list()
            )
        ],
        style={'display': 'inline-block'}
    ),
    html.Div(
        id='vgl_group_info'
    ),
    html.Div(
        id='vgl_vendor_list'
    )
]


@app_vndr.callback(
    dash.dependencies.Output('vgl_vendor_list', 'children'),
    [dash.dependencies.Input('vgl_groups', 'value')]
)
def populate_vndr_list(gid):
    """Callback to populate the vendor list.  Returns a list of divs, each with a vendor ID."""
    if gid:
        vendors = fetch_vndr_list(gid)

        return html.Div(
            [html.Div(
                v,
                style={'display': 'inline-block', 'margin': '5px', 'width': '8ch'}
            ) for v in vendors],
            style={'margin-top': '1em', 'margin-bottom': '1em'}
        )
    else:
        return None


@app_vndr.callback(
    dash.dependencies.Output('vgl_group_info', 'children'),
    [dash.dependencies.Input('vgl_groups', 'value')]
)
def populate_vndr_info(gid):
    """Callback to populate the vendor group info.  Returns a table with relevant info."""
    fields = {
        1: ('GID', 'GID'),
        2: ('VNDR_GROUP_NAME', 'Group Name'),
        3: ('PRM_STAKE_HOLDER_MP_ID', 'Group Owner'),
        4: ('IS_ACTIVE', 'Active Group?')
    }

    if gid:
        info = fetch_group_info(gid)
        info['PRM_STAKE_HOLDER_MP_ID'] = html.A(
            info['PRM_STAKE_HOLDER_MP_ID'],
            href='https://intra-wiw.e.corpintra.net/wiw/person/{}.html'.format(info['PRM_STAKE_HOLDER_MP_ID']),
            target='_blank'
        )

        return html.Table(
            [html.Tr([
                html.Td(html.B(v)),
                html.Td(info[k], style={'text-align': 'right'})
            ]) for i, (k, v) in fields.items()],
            style={'margin-top': '1em', 'margin-bottom': '1em'}
        )
    else:
        return None
