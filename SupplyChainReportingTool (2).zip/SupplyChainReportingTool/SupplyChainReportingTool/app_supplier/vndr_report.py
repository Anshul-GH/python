import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool import server, session, blu, cache, CACHE_TIMEOUT
from SupplyChainReportingTool import diff_month, add_months, month_tick_formater, month_filter
from SupplyChainReportingTool.app_supplier.app import app_vndr, list_to_options, vndr_list_all, custom_vndr_groups, clean_vndr_list
from SupplyChainReportingTool.app_supplier.app import custom_vndr_list, vndr_list, loc_list, item_list
from SupplyChainReportingTool.app_supplier.app import fetch_fulfillment_rate, fetch_EDI_stability, fetch_drop_ins, fetch_past_dues


layout_vndr_report = [
    dcc.Dropdown(  # Vendor list
        id='vndr_list',
        options=list_to_options((sorted(list(custom_vndr_list)) + [None] + vndr_list())),
        placeholder='Vendor ID'
    ),
    html.Button(
        '+',
        id='get_custom_vndr',
        # type='submit'
    ),
    html.Label(
        'Loc: ', 
        id='l_loc_list'
    ),
    dcc.Dropdown(  # Location list
        id='loc_list',
        options=[]
    ),
    html.Label(
        'Item: ', 
        id='l_item_list'
    ),
    dcc.Dropdown(  # Item list
        id='item_list',
        options=[]
    ),
    html.Label(
        '',
        id='l_frequency'
    ),
    dcc.RadioItems(  # Time granularity options
        options=[
            {'label': 'Monthly', 'value': 'month'},
            {'label': 'Weekly', 'value': 'week'},
            {'label': 'Daily', 'value': 'day'},
        ],
        value='month',
        id='frequency'
    ),
    dcc.Graph(
        id='data_graph',
        figure={
            'layout': go.Layout(
                yaxis=dict(title='Count', range=[0, 100], fixedrange=True,
                           side='right', zeroline=False, showgrid=False),
                yaxis2=dict(title='percent', range=[0, 1], fixedrange=True,
                            side='left', overlaying='y')
            ),
            'data': [go.Scatter(x=[], y=[], name='Data', mode='lines+markers')]
        }
    ),
    dcc.RangeSlider(
        id='date_range',
        min=0,
        max=diff_month(dt.datetime.now(), dt.date(2017, 1, 1)),
        marks=['{}'.format(
            month_tick_formater(add_months(dt.datetime(2017, 1, 1), k))
        ) for k in range(diff_month(dt.datetime.now(), dt.datetime(2017, 1, 1)) + 1)],
        pushable=0,
        value=[10, diff_month(dt.datetime.now(), dt.datetime(2017, 1, 1))]
    ),
    html.Div(  # Documentation div
        [
            html.H3('For each of the elements on the tool’s chart:'),
            html.Ul([
                html.Li('EDI stability: The average percent increase in order quantity relative to average order size'),
                html.Li([
                    'Quantity fulfillment: The quantity of parts delivered by a vendor as a percentage of the quantity we asked for',
                    html.Table([
                        html.Tr([
                            html.Td(html.B('Timing'), style={'text-align': 'center'}, colSpan=2)
                        ]),
                        html.Tr([
                                html.Td('Early'),
                                html.Td('Requirements & shipment ignored'),
                            ],
                            style={'background': '#c8dcb4', 'color': '#003340'}
                        ),
                        html.Tr([
                                    html.Td('On-time'),
                                    html.Td('% of requirements met (see Quantity)')
                                ],
                            style={'background': '#6ea046', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Late'),
                                html.Td('Requirements unmet (i.e. ASN_QTY = 0)'),
                            ],
                            style={'background': '#e69123', 'color': '#ffffff'}
                        ),
                        html.Tr([],
                                style={'height': '0.5em'}),
                        html.Tr([
                            html.Td(html.B('Quantity'), style={'text-align': 'center'}, colSpan=2)
                        ]),
                        html.Tr([
                                html.Td('Under-ship'),
                                html.Td('% of requirements met'),
                            ],
                            style={'background': '#e69123', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Exact'),
                                html.Td('100%')
                            ],
                            style={'background': '#6ea046', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Over-ship'),
                                html.Td('100% (ignores extra shipped)'),
                            ],
                            style={'background': '#c8dcb4', 'color': '#003340'}
                        ),
                    ])
                ]),
                html.Li('Order fulfillment: The number of 100% fulfilled orders as a percent of the total number of orders'),
                html.Li('Order Drop-Ins: The count of orders for which the first EDI was sent X days before the REQ_DATE where X is between, for example, 0 and 2'),
                html.Li('Past-Due %: The percent of orders within the given time window that had unaddressed past due requirements')
            ])
        ]
    ),
    html.Div(  # overlay div
        className='hidden',
        id='overlay',
        children=[
            html.Div(
                id='vndr_input',
                children=[
                    html.H2('Add a vendor...'),
                    dcc.Input(
                        placeholder='Vendor ID',
                        id='add_vndr_id',
                        value='',
                        type='text'
                    ),
                    html.Button(
                        'Add', 
                        id='add_vndr_id_submit',
                    )
                ],
                className='centered'
            )
        ]
    ),
    html.Div(
        id='/dev/null',
        style={'display': 'none'}
    )
]


@app_vndr.callback(
    dash.dependencies.Output('item_list', 'options'),
    [dash.dependencies.Input('loc_list', 'value')],
    [dash.dependencies.State('vndr_list', 'value')])
def update_item_list(loc, vndr_id):
    return [{'label': '(all)', 'value': '(all)'}] + \
           [{'label': "{} ({})".format(no, desc), 'value': no} for no, desc in item_list(vndr_id)]


@app_vndr.callback(
    dash.dependencies.Output('loc_list', 'options'),
    [dash.dependencies.Input('vndr_list', 'value')])
def update_loc_list(vndr_id):
    return [{'label': x, 'value': x} for x in loc_list(vndr_id)]


@app_vndr.callback(
    dash.dependencies.Output('item_list', 'value'),
    [dash.dependencies.Input('loc_list', 'value')])
def update_item_list_select_all(vndr_id):
    return '(all)'


@app_vndr.callback(
    dash.dependencies.Output('loc_list', 'value'),
    [dash.dependencies.Input('vndr_list', 'value')])
def update_loc_list_select_all(vndr_id):
    return '(all)'


@app_vndr.callback(
    dash.dependencies.Output('data_graph', 'figure'),
    [dash.dependencies.Input('loc_list', 'value'),
     dash.dependencies.Input('vndr_list', 'value'),
     dash.dependencies.Input('item_list', 'value'),
     dash.dependencies.Input('frequency', 'value'),
     dash.dependencies.Input('date_range', 'value')],
    [dash.dependencies.State('data_graph', 'figure')])
def populate_plot(loc, vndr_id, item_no, report_freq, date_range, previous_graph):
    visibilities = {d.get('name'): d.get('visible') for d in previous_graph['data']}
    
    granularity = {'day': 'CAL_DATE', 'week': 'END_OF_WEEK', 'month': 'END_OF_MONTH'}
    dtick = {
        'day': {'dtick': '86400000.0', 'tick0': '2000-01-03'},
        'week': {'dtick': '604800000.0', 'tick0': '2000-01-08'},
        'month': {'dtick': 'M1', 'tick0': '2000-01-31'}
    }
    
    date_from = month_filter(add_months(dt.datetime(2017, 1, 1), date_range[0]),
                             'start')
    date_to = month_filter(add_months(dt.datetime(2017, 1, 1), date_range[1]),
                           'end')
    server.logger.info(
        'Searching between {} and {}'.format(date_from.strftime('%Y-%m-%d'),
                                             date_to.strftime('%Y-%m-%d'))
    )
    
    if vndr_id:
        date_col = granularity[report_freq]
        grouping_cols = ['VNDR_ID']
        if loc != '(all)':
            grouping_cols += ['LOC']
        else:
            loc = None
        if item_no != '(all)':
            grouping_cols += ['ITEM_NO']
        else:
            item_no = None
        
        l = 'Fetching report for vendor {vndr}{loc}{item} grouping by {gran}'
        l = l.format(
            vndr=vndr_id,
            gran=date_col,
            loc=(" at location %s" % loc) if loc else "",
            item=(" for item %s" % item_no) if item_no else ""
        )
        server.logger.info(l)
        
        t_fulfill = fetch_fulfillment_rate(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_stability = fetch_EDI_stability(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_dropins = fetch_drop_ins(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_pastdue = fetch_past_dues(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        
        t_fulfill['ORDER_FULFILLMENT'] = t_fulfill['FULFILLED_FULLY_COUNT'] / t_fulfill['ROW_COUNT']
        t_fulfill['QUANTITY_FULFILLMENT_OVERALL'] = t_fulfill['FULFILLED_QTY_TOTAL'] / \
            (t_fulfill['REQ_QTY_CURR_DUE'] + t_fulfill['REQ_QTY_PAST_DUE'])
        t_fulfill['QUANTITY_FULFILLMENT'] = t_fulfill['QUANTITY_FULFILLMENT_OVERALL']
        t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE'] = t_fulfill['FULFILLED_QTY_CURR_DUE'] / t_fulfill['REQ_QTY_CURR_DUE']
        # t_fulfill.loc[t_fulfill['QUANTITY_FULFILLMENT_DUE'] < 0, 'QUANTITY_FULFILLMENT_DUE'] = 0
        t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'] = t_fulfill['FULFILLED_QTY_PAST_DUE'] / t_fulfill['REQ_QTY_PAST_DUE']
        # t_fulfill.loc[t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'] > 1, 'QUANTITY_FULFILLMENT_PAST_DUE'] = 1
        t_fulfill.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_stability['STAB_AVG'] = t_stability['ORDER_EDI_INSTABILITY_POSITIVE_ONLY'] / t_stability['ROW_COUNT']
        t_stability['STAB_WEIGHTED'] = t_stability['ORDER_EDI_INSTABILITY_POSITIVE_ONLY_X_UNIT_PRICE'] / \
            t_stability['CUR_UNIT_PRICE']
        t_stability.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_dropins.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_pastdue['PERCENT_ORDERS_PAST_DUE'] = t_pastdue['HAS_PAST_DUE'] / t_pastdue['TOTAL']        
        t_pastdue.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_fulfill = t_fulfill[(date_from <= t_fulfill['DATE']) & (t_fulfill['DATE'] <= date_to)]
        t_stability = t_stability[(date_from <= t_stability['DATE']) & (t_stability['DATE'] <= date_to)]
        t_dropins = t_dropins[(date_from <= t_dropins['DATE']) & (t_dropins['DATE'] <= date_to)]
        t_pastdue = t_pastdue[(date_from <= t_pastdue['DATE']) & (t_pastdue['DATE'] <= date_to)]
        
        server.logger.info("Fulfillment data from {} to {}".format(
            t_fulfill['DATE'].min().date(),
            t_fulfill['DATE'].max().date())
        )
        server.logger.info("EDI Stability data from {} to {}".format(
            t_stability['DATE'].min().date(),
            t_stability['DATE'].max().date())
        )
        server.logger.info("Drop-in data from {} to {}".format(
            t_dropins['DATE'].min().date(),
            t_dropins['DATE'].max().date())
        )
        server.logger.info("Past-due data from {} to {}".format(
            t_pastdue['DATE'].min().date(),
            t_pastdue['DATE'].max().date())
        )
        
        if loc is not None:
            t_fulfill = t_fulfill[t_fulfill['LOC'] == loc]
            t_stability = t_stability[t_stability['LOC'] == loc]
            t_dropins = t_dropins[t_dropins['LOC'] == loc]
            t_pastdue = t_pastdue[t_pastdue['LOC'] == loc]
        
        if item_no is not None:
            t_fulfill = t_fulfill[t_fulfill['ITEM_NO'] == item_no]
            t_stability = t_stability[t_stability['ITEM_NO'] == item_no]
            t_dropins = t_dropins[t_dropins['ITEM_NO'] == item_no]
            t_pastdue = t_pastdue[t_pastdue['ITEM_NO'] == item_no]
        
    if vndr_id is None or (t_fulfill.size == 0 and t_stability.size == 0 and
                           t_dropins.size == 0 and t_pastdue.size == 0):
        data = []
        ymax = 0
    else:
        ax_percent = {'yaxis': 'y2'}
        ax_count_1 = {}  # 'yaxis': 'y2'}
        
        name = 'EDI Stability'
        p_stability = go.Scatter(
            x=list(t_stability['DATE']),
            y=list(t_stability['STAB_WEIGHTED']),
            text=list(t_stability['STAB_WEIGHTED'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(204,121,167)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or 'legendonly',
            **ax_percent
        )
        
        name = 'Quantity Fulfillment: Overall'
        p_fulfillment_qty = go.Scatter(
            x=list(t_fulfill['DATE']),
            y=list(t_fulfill['QUANTITY_FULFILLMENT_OVERALL']),
            text=list(t_fulfill['QUANTITY_FULFILLMENT_OVERALL'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(0,145,230)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or 'legendonly',
            **ax_percent
        )
        
        name = 'Quantity Fulfillment: Due'
        p_fulfillment_qty_current = go.Scatter(
            x=list(t_fulfill['DATE']),
            y=list(t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE']),
            text=list(t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(0,114,178)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or True,
            **ax_percent
        )
        
        name = 'Quantity Fulfillment: Past-Due'
        p_fulfillment_qty_past = go.Scatter(
            x=list(t_fulfill['DATE']),
            y=list(t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE']),
            text=list(t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(0,81,128)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or 'legendonly',
            **ax_percent
        )
        
        name = 'Order Fulfillment'
        p_fulfillment_ord = go.Scatter(
            x=list(t_fulfill['DATE']),
            y=list(t_fulfill['ORDER_FULFILLMENT']),
            text=list(t_fulfill['ORDER_FULFILLMENT'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(230,159,0)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or True,
            **ax_percent
        )
        
        dropin_style = dict(
            hoverinfo='text+name',
            hoverlabel=dict(
                namelength=-1
            ),
            textposition='auto',
            visible=visibilities.get('Order Dropin-Ins: d<0') or 'legendonly'
        )
        dropin_style.update(ax_count_1)
        p_dropins_lt_0 = go.Bar(
            legendgroup='Order Dropins',
            x=list(t_fulfill['DATE']),
            y=list(t_dropins['DROP_IN_LT_0_ORDERS']),
            text=list(t_dropins['DROP_IN_LT_0_ORDERS']),
            name='Order Dropin-Ins: d<0',
            **dropin_style,
            marker={'color': '#cccccc'},
            textfont=dict(color='#000000')
        )
        p_dropins_0_2 = go.Bar(
            legendgroup='Order Dropins',
            x=list(t_fulfill['DATE']),
            y=list(t_dropins['DROP_IN_0_2_ORDERS']),
            text=list(t_dropins['DROP_IN_0_2_ORDERS']),
            name='Order Dropin-Ins: 0≤d≤2',
            **dropin_style,
            marker={'color': '#969696'},
            textfont=dict(color='#000000')
        )
        p_dropins_2_10 = go.Bar(
            legendgroup='Order Dropins',
            x=list(t_fulfill['DATE']),
            y=list(t_dropins['DROP_IN_2_10_ORDERS']),
            text=list(t_dropins['DROP_IN_2_10_ORDERS']),
            name='Order Dropin-Ins: 2<d≤10',
            **dropin_style,
            marker={'color': '#636363'},
            textfont=dict(color='#ffffff'),
        )
        p_dropins_10_20 = go.Bar(
            legendgroup='Order Dropins',
            x=list(t_fulfill['DATE']),
            y=list(t_dropins['DROP_IN_10_20_ORDERS']),
            text=list(t_dropins['DROP_IN_10_20_ORDERS']),
            name='Order Dropin-Ins: 10<d<20',
            **dropin_style,
            marker={'color': '#252525'},
            textfont=dict(color='#ffffff')
        )
        p_dropins_gt_20 = go.Bar(
            x=list(t_fulfill['DATE']),
            y=list(t_dropins['NOT_DROPIN']),
            text=list(t_dropins['NOT_DROPIN']),
            name='Order Dropin-Ins: not drop-in',
            **dropin_style,
            marker={'color': '#000000'},
            textfont=dict(color='#ffffff')
        )
        ymax = max(t_dropins['DROP_IN_LT_0_ORDERS'] + t_dropins['DROP_IN_0_2_ORDERS'] +
                   t_dropins['DROP_IN_2_10_ORDERS'] + t_dropins['DROP_IN_10_20_ORDERS'] + t_dropins['NOT_DROPIN'])
        
        name = 'Past-Due %'
        p_pastdue = go.Scatter(
            x=list(t_pastdue['DATE']),
            y=list(t_pastdue['PERCENT_ORDERS_PAST_DUE']),
            text=list(t_pastdue['PERCENT_ORDERS_PAST_DUE'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(0,158,115)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or 'legendonly',
            **ax_percent
        )
        
        name = 'Past-Due Count'
        p_pastdue_count = go.Scatter(
            x=list(t_pastdue['DATE']),
            y=list(t_pastdue['HAS_PAST_DUE']),
            text=list(t_pastdue['HAS_PAST_DUE'].round(decimals=3)),
            hoverinfo='text+name',
            name=name,
            mode='lines+markers',
            marker=dict(
                color='rgb(0,158,115)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            ),
            visible=visibilities.get(name) or 'legendonly'
        )
        
        data = [p_dropins_gt_20, p_dropins_10_20, p_dropins_2_10, p_dropins_0_2, p_dropins_lt_0,
                p_stability, p_fulfillment_qty, p_fulfillment_qty_current, p_fulfillment_qty_past, p_fulfillment_ord,
                p_pastdue, p_pastdue_count]
    
    layout = go.Layout(
        showlegend=True,
        legend=dict(orientation="h", x=0, y=1.3),
        barmode='stack',
        xaxis={
            **dtick[report_freq]
        },
        yaxis2=dict(
            title='Percent',
            range=[0, 1.1],
            fixedrange=True,
            side='left',
            overlaying='y'
        ),
        yaxis=dict(
            title='Count',
            range=[0, ymax],
            fixedrange=True,
            side='right',
            zeroline=False,
            showgrid=False
        )
    )
    
    return {'data': data, 'layout': layout}
