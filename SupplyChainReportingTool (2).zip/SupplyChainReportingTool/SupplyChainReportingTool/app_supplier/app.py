import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
from functools import partial
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool import server, session, blu, cache, CACHE_TIMEOUT
from SupplyChainReportingTool import diff_month, add_months, month_tick_formater, month_filter, Dash_responsive

custom_vndr_list = set(['DZ32', 'BF64', 'HF89', 'KBV2', 'KA75', 'AL53', 'KM10', 'KF28'])
button_click_n = {'get_custom_vndr': 0, 'add_vndr_id_submit': 0}

def custom_vndr_groups():
    sql = """
select VNDR_GROUP_NAME, varchar(GID) as GID
from SSZ_MATFLO.VNDR_GROUPS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUP_MEMBERS group by GID)
order by VNDR_GROUP_NAME
"""
    df = blu.fetch(sql, []).rename(columns={'VNDR_GROUP_NAME': 'label', 'GID': 'value'})
    
    return df.to_dict(orient='records')


@cache.memoize(timeout=CACHE_TIMEOUT)
def vndr_list_all():
    sql = """
select trim(B ' ' from VNDR_ID) as VNDR_ID
from MFGEDI.MFG_EDI_OTBND_ARCV
where ARCV_TS between (current timestamp - 1 year) and (current timestamp)
group by trim(B ' ' from VNDR_ID)
order by VNDR_ID
"""
    
    return list(blu.fetch(sql, []).VNDR_ID)


@cache.memoize(timeout=CACHE_TIMEOUT)
def vndr_list():
    sql = """
select * from (
    select 
        trim(B ' ' from VNDR_ID) as VNDR_ID, 
        avg(FULFILLMENT_RATE_OVERALL) as FULFILLMENT_RATE_ASN
    from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
    where
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_UNIT_COST group by VNDR_ID)
        and
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES group by VNDR_ID)
    group by VNDR_ID
    order by FULFILLMENT_RATE_ASN desc
    fetch first 15 rows only
)
union all
select * from (
    select 
        trim(B ' ' from VNDR_ID) as VNDR_ID, 
        avg(FULFILLMENT_RATE_OVERALL) as FULFILLMENT_RATE_ASN
    from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
    where
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_UNIT_COST group by VNDR_ID)
        and
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES group by VNDR_ID)
    group by VNDR_ID
    order by FULFILLMENT_RATE_ASN
    fetch first 15 rows only
)
"""
    sql_args = []
    
    return list(blu.fetch(sql, sql_args)['VNDR_ID'])


def vndr_db_custom():
    return [{'label': x, 'value': x} for x in (sorted(list(custom_vndr_list)) + [None] + vndr_list())]


def list_to_options(lst):
    return [{'label': x, 'value': x} for x in lst]


@cache.memoize(timeout=CACHE_TIMEOUT)
def loc_list(vndr_id):
    sql = """
select LOC
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE 
where VNDR_ID = ?
group by LOC
order by LOC
"""
    sql_args = [vndr_id]
    
    return ['(all)',] + list(blu.fetch(sql, sql_args)['LOC'])


@cache.memoize(timeout=CACHE_TIMEOUT)
def item_list(vndr_id):
    sql = """
select trim(B ' ' from ITEM_NO) as ITEM_NO, trim(B ' ' from ITEM_DESC) as ITEM_DESC
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE 
where VNDR_ID = ?
group by ITEM_NO, ITEM_DESC
order by ITEM_NO
"""
    sql_args = [vndr_id]
    return blu.fetch(sql, sql_args)[['ITEM_NO', 'ITEM_DESC']].values.tolist()


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_EDI_stability(vndr_id):
    """Fetches the edi stability records for a given vndr id as a pandas dataframe"""
    server.logger.info("Skipping cache for EDI Stability (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_EDI_STABILITY
where VNDR_ID = ?
    """
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    df['REQ_DATE'] = pd.to_datetime(df['REQ_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    df.rename(columns={'REQ_DATE': 'CAL_DATE'}, inplace=True)
    
    return df


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_fulfillment_rate(vndr_id):
    """Fetches the fulfillment rate records for a given vndr id as a pandas dataframe"""
    server.logger.info("Skipping cache for Fulfillment Rate (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_FULFILLMENT_RATE
where VNDR_ID = ?
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['CAL_DATE'] = pd.to_datetime(df['CAL_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
        
    return df


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_drop_ins(vndr_id):
    """Fetches the drop-in records for a given vndr id as a pandas dataframe"""
    server.logger.info("Skipping cache for Drop-Ins (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_DROP_INS
where VNDR_ID = ?
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['REQ_DATE'] = pd.to_datetime(df['REQ_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    df.rename(columns={'REQ_DATE': 'CAL_DATE'}, inplace=True)
    
    return df


@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_past_dues(vndr_id):
    """Fetches the past-due records for a given vndr id as a pandas dataframe"""
    server.logger.info("Skipping cache for Past-Dues (vndr='{}')".format(vndr_id))
    sql = """
select
    VNDR_ID
    ,LOC
    ,CAL_DATE
    ,last_day(CAL_DATE) as END_OF_MONTH
    ,CAL_DATE + (6 - mod(dayofweek(CAL_DATE), 7)) days as END_OF_WEEK
    ,trim(B ' ' from ITEM_NO) as ITEM_NO
    ,sum(case when REQ_QTY_PAST_DUE > 0 then 1 else 0 end) as HAS_PAST_DUE
    ,count(1) as TOTAL
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
where
    VNDR_ID = ?
group by
    VNDR_ID
    ,LOC
    ,CAL_DATE
    ,ITEM_NO
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['CAL_DATE'] = pd.to_datetime(df['CAL_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    return df


def clean_vndr_list(prim_vndr, vndr_list):
    """Returns a consistently prepared list of vendors.
    Inserts prim_vndr into the list.  Converts any GIDs (int values) into expanded
    list of vendor ids.
    
    :param prim_vndr: single vndr id as a string
    :param vndr_list: list of vndr ids and gids
    :returns: sorted list of vndr ids with gids converted to vndr ids
    """
    if '(all)' in vndr_list:
        return ['(all)']
    
    if prim_vndr:
        vndr_list += [prim_vndr]
    gids = [x for x in vndr_list if x.isdigit()]
    
    if len(gids) > 0:
        group_vndrs = blu.fetch("""
select distinct trim(B ' ' from VNDR_ID) as VNDR_ID
from SSZ_MATFLO.VNDR_GROUP_MEMBERS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUPS where IS_ACTIVE = 1)
and GID in ({})
            """.format(','.join(['?' for x in gids])), 
            gids).VNDR_ID.tolist()
    else: 
        group_vndrs = []
        
    vndr_list = [x for x in vndr_list if x not in gids] + group_vndrs
    
    return sorted(set(vndr_list))

compare_metrics = {
    'fulfillment': 'Curr Due Fulfillment Rate',
    'dropins': 'Drop-Ins',
    'stability': 'EDI Stability'
}
base_url = '/supplier/'
app_vndr = dash.Dash(__name__.split('.')[0], server=server, url_base_pathname=base_url)
app_vndr.css.append_css({'external_url': '/static/vendor.css'})
app_vndr.css.append_css({'external_url': '/static/compare.css'})
app_vndr.css.append_css({'external_url': '/static/comp_metric.css'})
app_vndr.css.append_css({'external_url': '/static/vndr_group_lookup.css'})
app_vndr.scripts.append_script({'external_url': '/static/vendor.js'})
app_vndr.config['suppress_callback_exceptions']=True
app_vndr.layout = html.Div(
    id='app',
    children=[
        dcc.Location(id='url', refresh=False),
        html.Div(
            base_url,
            id='base_url'
        ),
        html.Div(
            id='app_chooser',
            children=[
                dcc.Link(
                    'Vendor Report',
                    id='select_app_report',
                    href=base_url + 'vndr_report/'
                ),
                dcc.Link(
                    'Vendor Comparison',
                    id='select_app_research',
                    href=base_url + 'vndr_compare/'
                ),
                dcc.Link(
                    'Metric Comparison',
                    id='select_app_metric',
                    href=base_url + 'metric_comp/'
                ),
                dcc.Link(
                    'Vendor Groups',
                    id='select_app_groups',
                    href=base_url + 'custom_groups/'
                )
            ]
        ),
        html.Div(
            id='app_content'
        )
    ]
)

# Import layouts and callbacks for sub-pages
from SupplyChainReportingTool.app_supplier.vndr_report import layout_vndr_report
from SupplyChainReportingTool.app_supplier.metric_v_metric import layout_metric_compare
from SupplyChainReportingTool.app_supplier.vndr_comp import layout_vndr_compare
from SupplyChainReportingTool.app_supplier.vndr_group_lookup import layout_vndr_groups

@app_vndr.callback(
    dash.dependencies.Output('app_content', 'children'),
    [dash.dependencies.Input('url', 'pathname')],
    [dash.dependencies.State('base_url', 'children')]
)
def app_picked(url, base_url):
    """Callback returns layout for corresponding tool url."""    
    url = url.replace(base_url, '') if url else None
    
    server.logger.info("\n\nURL is '{}'\n\n".format(url))

    if url == 'vndr_report/' or url == '':
        return layout_vndr_report
    elif url == 'vndr_compare/':
        return layout_vndr_compare
    elif url == 'metric_comp/':
        return layout_metric_compare
    elif url == 'custom_groups/':
        return layout_vndr_groups
    else:
        return [html.H2('404'), html.P('App not found.'), html.P('Try one of the navbar links!')]

@app_vndr.callback(
    dash.dependencies.Output('overlay', 'className'),
    [dash.dependencies.Input('get_custom_vndr', 'n_clicks'),
     dash.dependencies.Input('add_vndr_id_submit', 'n_clicks')])
def show_input(b1_n, b2_n):
    b1_n = b1_n or 0
    b2_n = b2_n or 0
    
    if 'b1_n' not in session or b1_n < session['b1_n']:
        session['b1_n'] = b1_n
    if 'b2_n' not in session or b2_n < session['b2_n']:
        session['b2_n'] = b2_n
        
    if b1_n > 0 and b1_n > session['b1_n']:
        session['b1_n'] = b1_n
        return 'input'
    elif b2_n > 0 and b2_n > session['b2_n']:
        session['b2_n'] = b2_n
        return 'hidden'
    else:
        return 'hidden'

@app_vndr.callback(
    dash.dependencies.Output('vndr_list', 'options'),
    [dash.dependencies.Input('add_vndr_id_submit', 'n_clicks')],
    [dash.dependencies.State('add_vndr_id', 'value')])
def add_custom_vndr(n, vndr_ids):
    ids = vndr_ids.upper().split(',')
    
    server.logger.info('adding VNDR_IDs {}'.format(', '.join(x for x in ids)))
    
    custom_vndr_list.update(ids)
    
    return vndr_db_custom()





