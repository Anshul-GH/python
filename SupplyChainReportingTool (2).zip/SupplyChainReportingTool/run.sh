pushd ${0%/*}
source activate py35
export FLASK_APP=SupplyChainReportingTool
export FLASK_DEBUG=true

CONFIGFILE="$1/serviceaccount.conf"
export $(sed '1q;d' $CONFIGFILE)
export $(sed '2q;d' $CONFIGFILE)

echo AD_UID=$AD_UID

pip install -e .
python -m flask run --host 0.0.0.0 --port 8080

read -r -p "Press any key to continue..." -n 1
popd
