from setuptools import setup

setup(name='SupplyChainReportingTool',
      packages=['SupplyChainReportingTool'],
      include_package_data=True,
      install_requires=['flask',
                        'dash',
                        'pandas',
                        'bokeh',
                        'dtna_db2'])