import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool.app_supplier.app import app_vndr

compare_metrics = {
    'fulfillment': 'Curr Due Fulfillment Rate',
    'dropins': 'Drop-Ins',
    'stability': 'EDI Stability'
}

metric_compare = [
    html.Label('X-axis metric: '),
    dcc.Dropdown(
        id='metric_x',
        options=[
            {'label': l, 'value': v}
            for v, l in compare_metrics.items()
        ]
    ),
    html.Label('Y-axis metric: '),
    dcc.Dropdown(
        id='metric_y',
        options=[
            {'label': l, 'value': v}
            for v, l in compare_metrics.items()
        ]
    ),
]

@app_vndr.callback(
    dash.dependencies.Output('metric_y', 'options'),
    [dash.dependencies.Input('metric_x','value')]
)
def update_y_list(x_picked):
    return [
        {'label': l, 'value': v}
        for v, l in compare_metrics.items()
        if v != x_picked
    ]