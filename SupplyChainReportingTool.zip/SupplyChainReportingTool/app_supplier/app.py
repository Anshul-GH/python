import dash
import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objs as go
import pandas as pd
from functools import partial
import datetime as dt
from flask import request, send_file
from io import BytesIO

from SupplyChainReportingTool import server, session, blu, cache, CACHE_TIMEOUT
from SupplyChainReportingTool import diff_month, add_months, month_tick_formater, month_filter, Dash_responsive

custom_vndr_list = set(['DZ32', 'BF64', 'HF89', 'KBV2', 'KA75', 'AL53', 'KM10', 'KF28'])
button_click_n = {'get_custom_vndr': 0, 'add_vndr_id_submit': 0}

def custom_vndr_groups():
    sql = """
select VNDR_GROUP_NAME, varchar(GID) as GID
from SSZ_MATFLO.VNDR_GROUPS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUP_MEMBERS group by GID)
order by VNDR_GROUP_NAME
"""
    df = blu.fetch(sql, []).rename(columns={'VNDR_GROUP_NAME': 'label', 'GID': 'value'})
    
    return df.to_dict(orient='records')

@cache.memoize(timeout=CACHE_TIMEOUT)
def vndr_list_all():
    sql = """
select trim(B ' ' from VNDR_ID) as VNDR_ID
from MFGEDI.MFG_EDI_OTBND_ARCV
where ARCV_TS between (current timestamp - 1 year) and (current timestamp)
group by trim(B ' ' from VNDR_ID)
order by VNDR_ID
"""
    
    return list(blu.fetch(sql, []).VNDR_ID)

@cache.memoize(timeout=CACHE_TIMEOUT)
def vndr_list():
    sql = """
select * from (
    select 
        trim(B ' ' from VNDR_ID) as VNDR_ID, 
        avg(FULFILLMENT_RATE_OVERALL) as FULFILLMENT_RATE_ASN
    from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
    where
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_UNIT_COST group by VNDR_ID)
        and
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES group by VNDR_ID)
    group by VNDR_ID
    order by FULFILLMENT_RATE_ASN desc
    fetch first 15 rows only
)
union all
select * from (
    select 
        trim(B ' ' from VNDR_ID) as VNDR_ID, 
        avg(FULFILLMENT_RATE_OVERALL) as FULFILLMENT_RATE_ASN
    from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
    where
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_UNIT_COST group by VNDR_ID)
        and
        VNDR_ID in (select VNDR_ID from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES group by VNDR_ID)
    group by VNDR_ID
    order by FULFILLMENT_RATE_ASN
    fetch first 15 rows only
)
"""
    sql_args = []
    
    return list(blu.fetch(sql, sql_args)['VNDR_ID'])

def vndr_db_custom():
    return [{'label': x, 'value': x} for x in (sorted(list(custom_vndr_list)) + [None] + vndr_list())]

def list_to_options(lst):
    return [{'label': x, 'value': x} for x in lst]

@cache.memoize(timeout=CACHE_TIMEOUT)
def loc_list(vndr_id):
    sql = """
select LOC
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE 
where VNDR_ID = ?
group by LOC
order by LOC
"""
    sql_args = [vndr_id]
    
    return ['(all)',] + list(blu.fetch(sql, sql_args)['LOC'])

@cache.memoize(timeout=CACHE_TIMEOUT)
def item_list(vndr_id):
    sql = """
select trim(B ' ' from ITEM_NO) as ITEM_NO, trim(B ' ' from ITEM_DESC) as ITEM_DESC
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE 
where VNDR_ID = ?
group by ITEM_NO, ITEM_DESC
order by ITEM_NO
"""
    sql_args = [vndr_id]
    return blu.fetch(sql, sql_args)[['ITEM_NO', 'ITEM_DESC']].values.tolist()

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_EDI_stability(vndr_id):
    print("Skipping cache for EDI Stability (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_EDI_STABILITY
where VNDR_ID = ?
    """
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    df['REQ_DATE'] = pd.to_datetime(df['REQ_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    df.rename(columns={'REQ_DATE': 'CAL_DATE'}, inplace=True)
    
    return df

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_fulfillment_rate(vndr_id):
    print("Skipping cache for Fulfillment Rate (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_FULFILLMENT_RATE
where VNDR_ID = ?
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['CAL_DATE'] = pd.to_datetime(df['CAL_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
        
    return df

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_drop_ins(vndr_id):
    print("Skipping cache for Drop-Ins (vndr='{}')".format(vndr_id))
    sql = """
select *
from ML_PREDICT_SR.VENDOR_REPORT_DROP_INS
where VNDR_ID = ?
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['REQ_DATE'] = pd.to_datetime(df['REQ_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    df.rename(columns={'REQ_DATE': 'CAL_DATE'}, inplace=True)
    
    return df

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_past_dues(vndr_id):
    print("Skipping cache for Past-Dues (vndr='{}')".format(vndr_id))
    sql = """
select
    VNDR_ID
    ,LOC
    ,CAL_DATE
    ,last_day(CAL_DATE) as END_OF_MONTH
    ,CAL_DATE + (6 - mod(dayofweek(CAL_DATE), 7)) days as END_OF_WEEK
    ,trim(B ' ' from ITEM_NO) as ITEM_NO
    ,sum(case when REQ_QTY_PAST_DUE > 0 then 1 else 0 end) as HAS_PAST_DUE
    ,count(1) as TOTAL
from ML_PREDICT_SR.SUMRY_FULFILLMENT_RATE
where
    VNDR_ID = ?
group by
    VNDR_ID
    ,LOC
    ,CAL_DATE
    ,ITEM_NO
"""
    sql_options = [vndr_id]
    
    df = blu.fetch(sql, sql_options)
    
    df['CAL_DATE'] = pd.to_datetime(df['CAL_DATE'], infer_datetime_format=True)
    df['END_OF_WEEK'] = pd.to_datetime(df['END_OF_WEEK'], infer_datetime_format=True)
    df['END_OF_MONTH'] = pd.to_datetime(df['END_OF_MONTH'], infer_datetime_format=True)
    
    return df

@cache.memoize(timeout=CACHE_TIMEOUT)
def format_vndrcomp_sql(sql, vndr_list):
    if vndr_list is not None and len(vndr_list) > 0 and '(all)' not in vndr_list:
        sql = sql.format(
            'and (\n\t{}\n)'.format(
                'VNDR_ID in ({})'.format(','.join(['?' for _ in vndr_list]))
            )
        )
        
        sql_args = vndr_list
    else:
        sql = sql.format('')
        sql_args = []
    
    return sql, sql_args

def fetch_transform_vndrcomp_data(sql, sql_args):
    df = blu.fetch(sql, sql_args)
    df['DATE'] = df.DATE - pd.offsets.MonthBegin(1)
    
    return df

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_dropins(vndr_list):
    sql = """
select 
    trim(B ' ' from VNDR_ID) as VNDR_ID, 
    END_OF_MONTH as DATE, 
    sum(DROP_IN_LT_0_ORDERS + 
        DROP_IN_0_2_ORDERS + 
        DROP_IN_2_10_ORDERS) / (1.0 * sum(TOTAL_ORDERS)) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_DROP_INS
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_edistab(vndr_list):
    sql = """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    END_OF_MONTH as DATE,
    sum(ORDER_EDI_INSTABILITY_POSITIVE_ONLY_X_UNIT_PRICE) / sum(CUR_UNIT_PRICE) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_EDI_STABILITY
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))

@cache.memoize(timeout=CACHE_TIMEOUT)
def fetch_vndrcomp_currfulfill(vndr_list):
    sql = """
select
    trim(B ' ' from VNDR_ID) as VNDR_ID,
    END_OF_MONTH as DATE,
    sum(FULFILLED_QTY_CURR_DUE) / sum(REQ_QTY_CURR_DUE) as DATA
from ML_PREDICT_SR.VENDOR_REPORT_FULFILLMENT_RATE
where year(END_OF_MONTH) >= 2017 {}
group by trim(B ' ' from VNDR_ID), END_OF_MONTH
"""
    return fetch_transform_vndrcomp_data(*format_vndrcomp_sql(sql, vndr_list))

def vndrcomp_clean_pivot(df, prim_vndr, min_num_vndrs):
    dates = df[['VNDR_ID', 'DATE']].groupby(by=['DATE']).count().reset_index(level=0)
    df = df.loc[df.DATE >= dates.loc[dates.VNDR_ID > 0.25 * min_num_vndrs].DATE.min()]
    
    df_selection = df.pivot(index='VNDR_ID', columns='DATE', values='DATA')
    
    df_indv = df.loc[df.VNDR_ID == prim_vndr, ['DATA', 'DATE']].sort_values(by='DATE')
    
    return df_selection, df_indv

def clean_vndr_list(prim_vndr, vndr_list):
    if '(all)' in vndr_list:
        return ['(all)']
    
    vndr_list += [prim_vndr]
    gids = [x for x in vndr_list if x.isdigit()]
    
    if len(gids) > 0:
        group_vndrs = blu.fetch("""
select distinct trim(B ' ' from VNDR_ID) as VNDR_ID
from SSZ_MATFLO.VNDR_GROUP_MEMBERS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUPS where IS_ACTIVE = 1)
and GID in ({})
            """.format(','.join(['?' for x in gids])), 
            gids).VNDR_ID.tolist()
    else: 
        group_vndrs = []
        
    vndr_list = [x for x in vndr_list if x not in gids] + group_vndrs
    
    return sorted(set(vndr_list))

def fetch_vndr_compare_pivot(metric, prim_vndr, vndr_list):
    if vndr_list is not None and len(vndr_list) > 0 and '(all)' not in vndr_list:
        vndr_list += [prim_vndr]
        gids = [x for x in vndr_list if x.isdigit()]
        if len(gids) > 0:
            group_vndrs = blu.fetch("""
select distinct trim(B ' ' from VNDR_ID) as VNDR_ID
from SSZ_MATFLO.VNDR_GROUP_MEMBERS
where GID in (select GID from SSZ_MATFLO.VNDR_GROUPS where IS_ACTIVE = 1)
and GID in ({})
            """.format(','.join(['?' for x in gids])), 
            gids)
            vndr_list = [x for x in vndr_list if x not in gids] + group_vndrs.VNDR_ID.tolist()
        
        min_num_vndrs = len(set(vndr_list))
    else:
        gids = []
        group_vndrs = None
        vndr_list = ['(all)']
        min_num_vndrs = 300
    
    vndr_list = sorted(set(vndr_list))
    print('{} expands to {}'.format(gids, list(group_vndrs.VNDR_ID) if group_vndrs is not None else []))
    if metric == 'dropins':
        df = fetch_vndrcomp_dropins(vndr_list)
    elif metric == 'fulfillment':
        df = fetch_vndrcomp_currfulfill(vndr_list)
    else:
        df = fetch_vndrcomp_edistab(vndr_list)
    
    df_selection, df = vndrcomp_clean_pivot(df, prim_vndr, min_num_vndrs)
#    dates = df[['VNDR_ID', 'DATE']].groupby(by=['DATE']).count().reset_index(level=0)
#    df = df.loc[df.DATE >= dates.loc[dates.VNDR_ID > 0.25 * min_num_vndrs].DATE.min()]
    
#    df_selection = df.pivot(index='VNDR_ID', columns='DATE', values='DATA')
    x_sel = []
    y_sel = []
    for col in df_selection.columns:
        y_to_add = list(df_selection[col])
        x_sel += [col for _ in range(len(y_to_add))]
        y_sel += y_to_add
        
#    df = df.loc[df.VNDR_ID == prim_vndr, ['DATA', 'DATE']].sort_values(by='DATE')
    x_prim = list(df['DATE'])
    y_prim = list(df['DATA'])
    
    return x_sel, y_sel, x_prim, y_prim

compare_metrics = {
    'fulfillment': 'Curr Due Fulfillment Rate',
    'dropins': 'Drop-Ins',
    'stability': 'EDI Stability'
}
base_url = '/supplier/'
app_vndr = dash.Dash(__name__.split('.')[0], server=server, url_base_pathname=base_url)
app_vndr.css.append_css({'external_url': '/static/vendor.css'})
app_vndr.css.append_css({'external_url': '/static/compare.css'})
app_vndr.css.append_css({'external_url': '/static/comp_metric.css'})
app_vndr.scripts.append_script({'external_url': '/static/vendor.js'})
app_vndr.config['suppress_callback_exceptions']=True
app_vndr.layout = html.Div(
    id='app',
    children=[
        dcc.Location(id='url', refresh=False),
        html.Div(
            base_url,
            id='base_url'
        ),
        html.Div(
            id='app_chooser',
            children=[
                dcc.Link(
                    'Vendor Report',
                    id='select_app_report',
                    href=base_url + 'report/'
                ),
                dcc.Link(
                    'Vendor Comparison',
                    id='select_app_research',
                    href=base_url + 'compare/'
                ),
                dcc.Link(
                    'Metric Comparison',
                    id='select_app_metric',
                    href=base_url + 'metric_comp/'
                )
            ]
        ),
        html.Div(
            id='app_content'
        )
    ]
)
vndr_report = [
    dcc.Dropdown( # Vendor list
        id='vndr_list',
        options=list_to_options((sorted(list(custom_vndr_list)) + [None] + vndr_list())),
        placeholder='Vendor ID'
    ),
    html.Button(
        '+',
        id='get_custom_vndr',
        #type='submit'
    ),
    html.Label(
        'Loc: ', 
        id='l_loc_list'
    ),
    dcc.Dropdown( # Location list
        id='loc_list',
        options=[]
    ),
    html.Label(
        'Item: ', 
        id='l_item_list'
    ),
    dcc.Dropdown( # Item list
        id='item_list',
        options=[]
    ),
    html.Label(
        '',
        id='l_frequency'
    ),
    dcc.RadioItems( # Time granularity options
        options=[
            {'label': 'Monthly', 'value': 'month'},
            {'label': 'Weekly', 'value': 'week'},
            {'label': 'Daily', 'value': 'day'},
        ],
        value='month',
        id='frequency'
    ),
    dcc.Graph(
        id='data_graph',
        figure={
            'layout': go.Layout(
                yaxis=dict(title='Count',range=[0, 100],fixedrange=True,side='right',zeroline=False,showgrid=False),
                yaxis2=dict(title='percent',range=[0, 1],fixedrange=True,side='left',overlaying='y')
            ),
            'data': [go.Scatter(x=[],y=[],name='Data',mode='lines+markers')]
        }
    ),
    dcc.RangeSlider(
        id='date_range',
        min=0,
        max=diff_month(dt.datetime.now(), dt.date(2017,1,1)),
        marks=['{}'.format(
            month_tick_formater(add_months(dt.datetime(2017,1,1), k))
        ) for k in range(diff_month(dt.datetime.now(), dt.datetime(2017,1,1))+1)],
        pushable=0,
        value=[10,diff_month(dt.datetime.now(), dt.datetime(2017,1,1))]
    ),
    html.Div( # Documentation div
        [
            html.H3('For each of the elements on the tool’s chart:'),
            html.Ul([
                html.Li('EDI stability: The average percent increase in order quantity relative to average order size'),
                html.Li([
                    'Quantity fulfillment: The quantity of parts delivered by a vendor as a percentage of the quantity we asked for',
                    html.Table([
                        html.Tr([
                            html.Td(html.B('Timing'), style={'text-align': 'center'}, colSpan=2)
                        ]),
                        html.Tr([
                                html.Td('Early'),
                                html.Td('Requirements & shipment ignored'),
                            ],
                            style={'background': '#c8dcb4', 'color': '#003340'}
                        ),
                        html.Tr([
                                html.Td('On-time'),
                                html.Td('% of requirements met (see Quantity)')
                            ],
                            style={'background': '#6ea046', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Late'),
                                html.Td('Requirements unmet (i.e. ASN_QTY = 0)'),
                            ],
                            style={'background': '#e69123', 'color': '#ffffff'}
                        ),
                        html.Tr([],
                                style={'height': '0.5em'}),
                        html.Tr([
                            html.Td(html.B('Quantity'), style={'text-align': 'center'}, colSpan=2)
                        ]),
                        html.Tr([
                                html.Td('Under-ship'),
                                html.Td('% of requirements met'),
                            ],
                            style={'background': '#e69123', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Exact'),
                                html.Td('100%')
                            ],
                            style={'background': '#6ea046', 'color': '#ffffff'}
                        ),
                        html.Tr([
                                html.Td('Over-ship'),
                                html.Td('100% (ignores extra shipped)'),
                            ],
                            style={'background': '#c8dcb4', 'color': '#003340'}
                        ),
                    ])
                ]),
                html.Li('Order fulfillment: The number of 100% fulfilled orders as a percent of the total number of orders'),
                html.Li('Order Drop-Ins: The count of orders for which the first EDI was sent X days before the REQ_DATE where X is between, for example, 0 and 2'),
                html.Li('Past-Due %: The percent of orders within the given time window that had unaddressed past due requirements')
            ])
        ]
    ),
    html.Div( #overlay div
        className='hidden',
        id='overlay',
        children = [
            html.Div(
                id='vndr_input'
                ,children=[
                    html.H2('Add a vendor...'),
                    dcc.Input(
                        placeholder='Vendor ID',
                        id='add_vndr_id',
                        value='',
                        type='text'
                    ),
                    html.Button(
                        'Add', 
                        id='add_vndr_id_submit',
                    )
                ],
                className='centered'
            )
        ]
    ),
    html.Div(
        id='/dev/null',
        style={'display': 'none'}
    )
]
vndr_compre = [
    dcc.Dropdown(
        id='metric_list',
        options=[
            {'label': l, 'value': v}
            for v, l in compare_metrics.items()
        ],
        value='stability'
    ),
    html.Span(
        style={'width': '5ch', 'display': 'inline-block'}
    ),
    html.Div(
        style={'display': 'inline-block'},
        children=[
            dcc.Dropdown( # Vendor list
                id='vndr_list_prim',
                options=list_to_options(vndr_list_all()),
                placeholder='Vendor ID'
            ),
            html.Span(
                ' vs ',
                style={'vertical-align': 'middle'}
            ),
            dcc.Dropdown( # Vendor list
                id='vndr_list_scnd',
                options=list_to_options(['(all)']) + custom_vndr_groups() + list_to_options(vndr_list_all()),
                placeholder='Vendor IDs',
                multi=True
            )
        ]
    ),
    dcc.Graph(
        id='compare-chart',
        figure={
            'layout': go.Layout(
                yaxis=dict(title='percent',range=[0, 1],fixedrange=True,side='right',zeroline=False,showgrid=False)
            ),
            'data': [go.Scatter(x=[],y=[],name='Data',mode='lines+markers')]
        }
    ),
    html.Br(),
    html.A(
        'Download data',
        id='vndrcomp_dl_data',
        href='/dl/',
        className='btn'
    ),
]

from SupplyChainReportingTool.app_supplier.metric_v_metric import *

@app_vndr.callback(
    dash.dependencies.Output('app_content', 'children'),
    [dash.dependencies.Input('url', 'pathname')],
    [dash.dependencies.State('base_url', 'children')]
)
def app_picked(url, base_url):
    url = url.replace(base_url, '') if url else None
    
    print("\n\nURL is '{}'\n\n".format(url))
    
    if url == 'compare/':
        return vndr_compre
    elif url == 'metric_comp/':
        return metric_compare
    else:
        return vndr_report

@app_vndr.callback(
    dash.dependencies.Output('vndrcomp_dl_data', 'href'),
    [dash.dependencies.Input('metric_list','value'),
     dash.dependencies.Input('vndr_list_prim','value'),
     dash.dependencies.Input('vndr_list_scnd','value')]
)
def update_dl_url(metric, prim_vndr, scnd_vndr):
    print('I GOT CALLED')
    print(metric, prim_vndr, scnd_vndr)
    return '/dl/{}/?vndr={}&vndr_list={}'.format(metric, prim_vndr, ','.join(scnd_vndr) if scnd_vndr else None)

@app_vndr.callback(
    dash.dependencies.Output('compare-chart', 'figure'),
    [dash.dependencies.Input('metric_list','value'),
     dash.dependencies.Input('vndr_list_prim','value'),
     dash.dependencies.Input('vndr_list_scnd','value')]
)
def populate_compare_chart(metric, prim_vndr, scnd_vndr):
    print("\n\n'{}'\n'{}'\n'{}'\n\n".format(metric, prim_vndr, scnd_vndr))
    
    if prim_vndr is None or scnd_vndr is None or len(scnd_vndr) == 0:
        data = [go.Scatter(x=[],y=[],name='Data',mode='lines+markers')]
    else:
        x_sel, y_sel, x_prim, y_prim = fetch_vndr_compare_pivot(metric, prim_vndr, [x for x in scnd_vndr if x])
        data = [
            go.Box(
                y=y_sel,
                x=x_sel,
                name='Supply Base' if '(all)' in scnd_vndr else 'Selected Vendors',
                boxpoints='outliers'
            ),
            go.Scatter(
                x=x_prim,
                y=y_prim,
                name=prim_vndr
            )
        ]
    
    return {
        'layout': go.Layout(
            title=compare_metrics[metric],
            yaxis=dict(
                title='percent',
                range=[0, 1],
                fixedrange=True,
                side='left',
                zeroline=True,
                showgrid=True
            ),
            xaxis=dict(
                dtick='M1'
            )
        ),
        'data': data
    }

@app_vndr.callback(
    dash.dependencies.Output('overlay', 'className'),
    [dash.dependencies.Input('get_custom_vndr', 'n_clicks'),
     dash.dependencies.Input('add_vndr_id_submit', 'n_clicks')])
def show_input(b1_n, b2_n):
    b1_n = b1_n or 0
    b2_n = b2_n or 0
    
    if 'b1_n' not in session or b1_n < session['b1_n']:
        session['b1_n'] = b1_n
    if 'b2_n' not in session or b2_n < session['b2_n']:
        session['b2_n'] = b2_n
        
    if b1_n > 0 and b1_n > session['b1_n']:
        session['b1_n'] = b1_n
        return 'input'
    elif b2_n > 0 and b2_n > session['b2_n']:
        session['b2_n'] = b2_n
        return 'hidden'
    else:
        return 'hidden'

@app_vndr.callback(
    dash.dependencies.Output('vndr_list', 'options'),
    [dash.dependencies.Input('add_vndr_id_submit', 'n_clicks')],
    [dash.dependencies.State('add_vndr_id', 'value')])
def add_custom_vndr(n, vndr_ids):
    ids = vndr_ids.split(',')
    
    print('adding VNDR_IDs {}'.format(', '.join(x for x in ids)))
    
    custom_vndr_list.update(ids)
    
    return vndr_db_custom()

@app_vndr.callback(
    dash.dependencies.Output('loc_list', 'options'),
    [dash.dependencies.Input('vndr_list', 'value')])
def update_loc_list(vndr_id):
    return [{'label': x, 'value': x} for x in loc_list(vndr_id)]
    
@app_vndr.callback(
    dash.dependencies.Output('loc_list', 'value'),
    [dash.dependencies.Input('vndr_list', 'value')])
def update_loc_list_select_all(vndr_id):
    return '(all)'

@app_vndr.callback(
    dash.dependencies.Output('item_list', 'options'),
    [dash.dependencies.Input('loc_list', 'value')],
    [dash.dependencies.State('vndr_list', 'value')])
def update_item_list(loc, vndr_id):    
    return [{'label': '(all)', 'value': '(all)'}] + \
           [{'label': "{} ({})".format(no, desc), 'value': no} for no, desc in item_list(vndr_id)]
    
@app_vndr.callback(
    dash.dependencies.Output('item_list', 'value'),
    [dash.dependencies.Input('loc_list', 'value')])
def update_item_list_select_all(vndr_id):
    return '(all)'

@app_vndr.callback(
    dash.dependencies.Output('data_graph', 'figure'),
    [dash.dependencies.Input('loc_list', 'value'),
     dash.dependencies.Input('vndr_list', 'value'),
     dash.dependencies.Input('item_list', 'value'),
     dash.dependencies.Input('frequency', 'value'),
     dash.dependencies.Input('date_range', 'value')],
    [dash.dependencies.State('data_graph', 'figure')])
def populate_plot(loc, vndr_id, item_no, report_freq, date_range, previous_graph):
    visibilities = {d.get('name'): d.get('visible') for d in previous_graph['data']}
    
    for k,v in visibilities.items():
        print('{}: {}'.format(k.encode('utf-8'), v))
    
    granularity = {'day': 'CAL_DATE', 'week': 'END_OF_WEEK', 'month': 'END_OF_MONTH'}
    dtick = {
        'day': {'dtick': '86400000.0', 'tick0': '2000-01-03'},
        'week': {'dtick': '604800000.0', 'tick0': '2000-01-08'},
        'month': {'dtick': 'M1', 'tick0': '2000-01-31'}
    }
    
    date_from = month_filter(add_months(dt.datetime(2017,1,1), date_range[0]),
                             'start')
    date_to = month_filter(add_months(dt.datetime(2017,1,1), date_range[1]),
                           'end')
    print('Searching between {} and {}'.format(date_from.strftime('%Y-%m-%d'),
                                               date_to.strftime('%Y-%m-%d')))
    
    if vndr_id:
        date_col = granularity[report_freq]
        grouping_cols = ['VNDR_ID']
        if loc != '(all)':
            grouping_cols += ['LOC']
        else:
            loc = None
        if item_no != '(all)':
            grouping_cols += ['ITEM_NO']
        else:
            item_no = None
        
        l = 'Fetching report for vendor {vndr}{loc}{item} grouping by {gran}'
        l = l.format(
            vndr=vndr_id,
            gran=date_col,
            loc=(" at location %s" % loc) if loc else "",
            item=(" for item %s" % item_no) if item_no else ""
        )
        print(l)
        
        
        t_fulfill = fetch_fulfillment_rate(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_stability = fetch_EDI_stability(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_dropins = fetch_drop_ins(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        t_pastdue = fetch_past_dues(vndr_id).groupby(grouping_cols + [date_col], as_index=False).sum()
        
        t_fulfill['ORDER_FULFILLMENT'] = t_fulfill['FULFILLED_FULLY_COUNT'] / t_fulfill['ROW_COUNT']
        t_fulfill['QUANTITY_FULFILLMENT_OVERALL'] = t_fulfill['FULFILLED_QTY_TOTAL'] / (t_fulfill['REQ_QTY_CURR_DUE'] + t_fulfill['REQ_QTY_PAST_DUE'])
        t_fulfill['QUANTITY_FULFILLMENT'] = t_fulfill['QUANTITY_FULFILLMENT_OVERALL']
        t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE'] = t_fulfill['FULFILLED_QTY_CURR_DUE'] / t_fulfill['REQ_QTY_CURR_DUE']
        #t_fulfill.loc[t_fulfill['QUANTITY_FULFILLMENT_DUE'] < 0, 'QUANTITY_FULFILLMENT_DUE'] = 0
        t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'] = t_fulfill['FULFILLED_QTY_PAST_DUE'] / t_fulfill['REQ_QTY_PAST_DUE']
        #t_fulfill.loc[t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'] > 1, 'QUANTITY_FULFILLMENT_PAST_DUE'] = 1
        t_fulfill.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_stability['STAB_AVG'] = t_stability['ORDER_EDI_INSTABILITY_POSITIVE_ONLY'] / t_stability['ROW_COUNT']
        t_stability['STAB_WEIGHTED'] = t_stability['ORDER_EDI_INSTABILITY_POSITIVE_ONLY_X_UNIT_PRICE'] / t_stability['CUR_UNIT_PRICE']
        t_stability.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_dropins.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_pastdue['PERCENT_ORDERS_PAST_DUE'] = t_pastdue['HAS_PAST_DUE'] / t_pastdue['TOTAL']        
        t_pastdue.rename(columns={date_col: 'DATE'}, inplace=True)
        
        t_fulfill = t_fulfill[(date_from <= t_fulfill['DATE']) & (t_fulfill['DATE'] <= date_to)]
        t_stability = t_stability[(date_from <= t_stability['DATE']) & (t_stability['DATE'] <= date_to)]
        t_dropins = t_dropins[(date_from <= t_dropins['DATE']) & (t_dropins['DATE'] <= date_to)]
        t_pastdue = t_pastdue[(date_from <= t_pastdue['DATE']) & (t_pastdue['DATE'] <= date_to)]
        
        print("Fulfillment data from {} to {}".format(t_fulfill['DATE'].min().date(),
                                                      t_fulfill['DATE'].max().date()))
        print("EDI Stability data from {} to {}".format(t_stability['DATE'].min().date(),
                                                        t_stability['DATE'].max().date()))
        print("Drop-in data from {} to {}".format(t_dropins['DATE'].min().date(),
                                                  t_dropins['DATE'].max().date()))
        print("Past-due data from {} to {}".format(t_pastdue['DATE'].min().date(),
                                                  t_pastdue['DATE'].max().date()))
        
        if loc is not None:
            t_fulfill = t_fulfill[t_fulfill['LOC'] == loc]
            t_stability = t_stability[t_stability['LOC'] == loc]
            t_dropins = t_dropins[t_dropins['LOC'] == loc]
            t_pastdue = t_pastdue[t_pastdue['LOC'] == loc]
        
        if item_no is not None:
            t_fulfill = t_fulfill[t_fulfill['ITEM_NO'] == item_no]
            t_stability = t_stability[t_stability['ITEM_NO'] == item_no]
            t_dropins = t_dropins[t_dropins['ITEM_NO'] == item_no]
            t_pastdue = t_pastdue[t_pastdue['ITEM_NO'] == item_no]
        
    if vndr_id is None or (t_fulfill.size == 0 and t_stability.size == 0 and t_dropins.size == 0 and t_pastdue.size == 0):
        data = []
        ymax = 0
    else:    
        ax_percent = {'yaxis': 'y2'}
        ax_count_1 = {}#'yaxis': 'y2'}
        
        name = 'EDI Stability'
        print('\n\nusing {} (visibilities was {})\n\n'.format(visibilities.get(name) or 'legendonly', visibilities.get(name)))
        p_stability = go.Scatter(
            x=list(t_stability['DATE'])
            ,y=list(t_stability['STAB_WEIGHTED'])
            ,text=list(t_stability['STAB_WEIGHTED'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(204,121,167)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or 'legendonly'
            ,**ax_percent
        )
        
        name = 'Quantity Fulfillment: Overall'
        p_fulfillment_qty = go.Scatter(
            x=list(t_fulfill['DATE'])
            ,y=list(t_fulfill['QUANTITY_FULFILLMENT_OVERALL'])
            ,text=list(t_fulfill['QUANTITY_FULFILLMENT_OVERALL'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(0,145,230)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or 'legendonly'
            ,**ax_percent
        )
        
        name = 'Quantity Fulfillment: Due'
        p_fulfillment_qty_current = go.Scatter(
            x=list(t_fulfill['DATE'])
            ,y=list(t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE'])
            ,text=list(t_fulfill['QUANTITY_FULFILLMENT_CURR_DUE'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(0,114,178)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or True
            ,**ax_percent
        )
        
        name = 'Quantity Fulfillment: Past-Due'
        p_fulfillment_qty_past = go.Scatter(
            x=list(t_fulfill['DATE'])
            ,y=list(t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'])
            ,text=list(t_fulfill['QUANTITY_FULFILLMENT_PAST_DUE'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(0,81,128)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or 'legendonly'
            ,**ax_percent
        )
        
        name = 'Order Fulfillment'
        p_fulfillment_ord = go.Scatter(
            x=list(t_fulfill['DATE'])
            ,y=list(t_fulfill['ORDER_FULFILLMENT'])
            ,text=list(t_fulfill['ORDER_FULFILLMENT'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(230,159,0)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or True
            ,**ax_percent
        )
        
        dropin_style=dict(
            hoverinfo='text+name'
            ,hoverlabel=dict(
                namelength=-1
            )
            ,textposition = 'auto'
            ,visible=visibilities.get('Order Dropin-Ins: d<0') or 'legendonly'
        )
        dropin_style.update(ax_count_1)
        p_dropins_lt_0 = go.Bar(
            legendgroup='Order Dropins'
            ,x=list(t_fulfill['DATE'])
            ,y=list(t_dropins['DROP_IN_LT_0_ORDERS'])
            ,text=list(t_dropins['DROP_IN_LT_0_ORDERS'])
            ,name='Order Dropin-Ins: d<0'
            ,**dropin_style
            ,marker={'color':'#cccccc'}
            ,textfont=dict(color='#000000')
        )
        p_dropins_0_2 = go.Bar(
            legendgroup='Order Dropins'
            ,x=list(t_fulfill['DATE'])
            ,y=list(t_dropins['DROP_IN_0_2_ORDERS'])
            ,text=list(t_dropins['DROP_IN_0_2_ORDERS'])
            ,name='Order Dropin-Ins: 0≤d≤2'
            ,**dropin_style
            ,marker={'color':'#969696'}
            ,textfont=dict(color='#000000')
        )
        p_dropins_2_10 = go.Bar(
            legendgroup='Order Dropins'
            ,x=list(t_fulfill['DATE'])
            ,y=list(t_dropins['DROP_IN_2_10_ORDERS'])
            ,text=list(t_dropins['DROP_IN_2_10_ORDERS'])
            ,name='Order Dropin-Ins: 2<d≤10'
            ,**dropin_style
            ,marker={'color':'#636363'}
            ,textfont=dict(color='#ffffff')
        )
        p_dropins_10_20 = go.Bar(
            legendgroup='Order Dropins'
            ,x=list(t_fulfill['DATE'])
            ,y=list(t_dropins['DROP_IN_10_20_ORDERS'])
            ,text=list(t_dropins['DROP_IN_10_20_ORDERS'])
            ,name='Order Dropin-Ins: 10<d<20'
            ,**dropin_style
            ,marker={'color':'#252525'}
            ,textfont=dict(color='#ffffff')
        )
        p_dropins_gt_20 = go.Bar(
            x=list(t_fulfill['DATE'])
            ,y=list(t_dropins['NOT_DROPIN'])
            ,text=list(t_dropins['NOT_DROPIN'])
            ,name='Order Dropin-Ins: not drop-in'
            ,**dropin_style
            ,marker={'color':'#000000'}
            ,textfont=dict(color='#ffffff')
        )
        ymax = max(t_dropins['DROP_IN_LT_0_ORDERS'] + t_dropins['DROP_IN_0_2_ORDERS'] + t_dropins['DROP_IN_2_10_ORDERS'] + t_dropins['DROP_IN_10_20_ORDERS'] + t_dropins['NOT_DROPIN'])
        
        name = 'Past-Due %'
        p_pastdue = go.Scatter(
            x=list(t_pastdue['DATE'])
            ,y=list(t_pastdue['PERCENT_ORDERS_PAST_DUE'])
            ,text=list(t_pastdue['PERCENT_ORDERS_PAST_DUE'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(0,158,115)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or 'legendonly'
            ,**ax_percent
        )
        
        name = 'Past-Due Count'
        p_pastdue_count = go.Scatter(
            x=list(t_pastdue['DATE'])
            ,y=list(t_pastdue['HAS_PAST_DUE'])
            ,text=list(t_pastdue['HAS_PAST_DUE'].round(decimals=3))
            ,hoverinfo='text+name'
            ,name=name
            ,mode='lines+markers'
            ,marker=dict(
                color='rgb(0,158,115)',
                size=15,
                opacity=1,
                line={'width': 0.5, 'color': 'white'}
            )
            ,visible=visibilities.get(name) or 'legendonly'
        )
        
        data = [p_dropins_gt_20, p_dropins_10_20, p_dropins_2_10, p_dropins_0_2, p_dropins_lt_0,
                p_stability, p_fulfillment_qty, p_fulfillment_qty_current, p_fulfillment_qty_past, p_fulfillment_ord, p_pastdue, p_pastdue_count]
    
    layout = go.Layout(
        showlegend=True
        ,legend=dict(orientation="h",x=0, y=1.3)
        ,barmode='stack'
        ,xaxis={
            **dtick[report_freq]
        }
        ,yaxis2=dict(
            title='Percent'
            ,range=[0,1.1]
            ,fixedrange=True
            ,side='left'
            ,overlaying='y'
        )
        ,yaxis=dict(
            title='Count'
            ,range=[0, ymax]
            ,fixedrange=True
            ,side='right'
            ,zeroline=False
            ,showgrid=False
        )
    )
    
    return {'data': data, 'layout': layout}

@server.route('/dl/<string:metric>/')
def dl(metric):
    prim_vndr = request.args.get('vndr').upper()
    vndr_list = request.args.get('vndr_list').replace(' ', '').upper().split(',')
    vndr_list = clean_vndr_list(prim_vndr, vndr_list)
    
    if metric == 'fulfillment':
        df = fetch_vndrcomp_currfulfill(vndr_list)
    elif metric == 'stability':
        df = fetch_vndrcomp_edistab(vndr_list)
    elif metric == 'dropins':
        df = fetch_vndrcomp_dropins(vndr_list)
    
    df.sort_values(by=['DATE', 'VNDR_ID'], inplace=True)
    
    df_selection, df = vndrcomp_clean_pivot(df, prim_vndr, 1)
    df = df.rename(columns={'DATA': metric})
    
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    wb = writer.book
    frmt_date = wb.add_format({'num_format': 'mmm-yyy'})
    
    df.to_excel(writer, index=False, sheet_name=prim_vndr, columns=['DATE', metric])    
    ws_vndr = writer.sheets[prim_vndr]
    ws_vndr.set_column('A:A', 18, frmt_date)
    
    df_selection.to_excel(writer, index=True, sheet_name='Selected Vendors')
    ws_grup = writer.sheets['Selected Vendors']
    
    
    writer.save()
    writer.close()
    output.seek(0)
    
    return send_file(output, attachment_filename=metric+'.xlsx', as_attachment=True)