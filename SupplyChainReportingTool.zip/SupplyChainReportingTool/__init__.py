import os
from flask import Flask, request, session, render_template, jsonify, send_file, send_from_directory
from flask_caching import Cache
from flask_basicauth import BasicAuth
import pandas as pd
from dtna_db2.db_con import DB2
from dtna_db2.db_con_params import db_dwaprep, db_dwaprod, db_string
import dash

import datetime, calendar



if os.environ.get('AD_UID') is None or os.environ.get('AD_PWD') is None:
    raise EnvironmentError('DB credentials not present as environment variables.  '
                           'Make sure \'AD_UID\' and \'AD_PWD\' are set.')
blu = DB2(db_dwaprod,
          dict(uid=os.environ.get('AD_UID'), 
               pwd=os.environ.get('AD_PWD')), 
          db_string)

server = Flask(__name__)
server.secret_key = 'afds98ajkl;3245kja;lfads987235kasdf'
server.config['tool_auth'] = blu.fetch('select * from ML_PREDICT_SR.TOOLAUTH', sql_args=[]).to_dict(orient='records')[0]
server.config['BASIC_AUTH_USERNAME'] = server.config['tool_auth']['UID']
server.config['BASIC_AUTH_PASSWORD'] = server.config['tool_auth']['PWD_HASH']
server.config['BASIC_AUTH_FORCE'] = True
basic_auth = BasicAuth(server)

CACHE_TIMEOUT = 3600#86400 #seconds
cache = Cache(server, config={
    'CACHE_TYPE': 'filesystem',
    'CACHE_DIR': '/cache-directory/'
})

@server.after_request
def add_ua_compat(response):
    response.headers['X-UA-Compatible'] = 'IE=edge'
    return response

@server.route('/')
def main():
    return render_template("index.html")

@server.route('/static/path:path')
def static_file(path):
    static_folder = os.path.join(os.getcwd(), 'static')
    return send_from_directory(static_folder)

@server.route('/update_auth/')
def update_auth():
    server.config['tool_auth'] = blu.fetch('select * from ML_PREDICT_SR.TOOLAUTH', sql_args=[]).to_dict(orient='records')[0]
    server.config['BASIC_AUTH_USERNAME'] = server.config['tool_auth']['UID']
    server.config['BASIC_AUTH_PASSWORD'] = server.config['tool_auth']['PWD_HASH']
    return 'Auth updated'

def diff_month(d1, d2):
        return (d1.year - d2.year) * 12 + d1.month - d2.month

def add_months(sourcedate, months):
    month = sourcedate.month - 1 + months
    year = sourcedate.year + month // 12
    month = month % 12 + 1
    day = min(sourcedate.day, calendar.monthrange(year,month)[1])
    return datetime.date(year,month,day)
    
def month_tick_formater(date):
    if date.month == 1:
        return date.strftime('%b %Y')
    else:
        return date.strftime('%b')

def month_filter(date, start_end=None):    
    if start_end is None or start_end == "start":
        return datetime.date(date.year, date.month, 1)
    elif start_end == 'end':
        new_date = add_months(date, 1)
        new_date -= datetime.timedelta(days=1)
        return new_date

class Dash_responsive(dash.Dash):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    #Overriding from https://github.com/plotly/dash/blob/master/dash/dash.py#L282
    def index(self, *args, **kwargs):
        scripts = self._generate_scripts_html()
        css = self._generate_css_dist_html()
        config = self._generate_config_html()
        title = getattr(self, 'title', 'Dash')
        html = '''
        <!DOCTYPE html>
        <html lang="en">
            <head>
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta charset="UTF-8"/>
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                <title>{title}</title>
                {css}
            </head>
            <body>
                <div id="react-entry-point">
                    <div class="_dash-loading">
                        Loading...
                    </div>
                </div>
            </body>
            <footer>
                {config}
                {scripts}
            </footer>
        </html>
        '''
        return html.format(title=title, css=css, config=config, scripts=scripts)


import SupplyChainReportingTool.app_supplier.app as app_supplier
import SupplyChainReportingTool.app_instability.app as app_instability
