from io import BytesIO
from flask import Flask, request, session, render_template, jsonify, send_file
from bokeh.embed import components
from bokeh.plotting import figure
from bokeh.models.tools import HoverTool, WheelZoomTool
from bokeh.models import ColumnDataSource
import pandas as pd

from SupplyChainReportingTool import server, blu

def fetch_order_summary(item_no, loc, req_date):
    sql = """
    select * 
    from ML_PREDICT_SR.STG_EDI_AVOB_MASTER
    where 
        ITEM_NO = ?
        and
        LOC = ?
        and
        REQ_DATE = ?
    """
    return blu.fetch(sql, [item_no, loc, req_date])
         
def fetch_EDIs(item_no, loc, req_date):
    sql = """
    with d as (
        select date(TS_LOAD) as EDI_DATE, otbnd.ARCV_TS, ITEM_NO, LOC, VNDR_ID, REQ_DATE, REQ_QTY
        from MFGEDI.MFG_EDI_OTBND_ARCV otbnd
        left outer join MFGEDI.MFG_EDI_SENT sent
        on 
            sent.ARCV_TS = otbnd.ARCV_TS
            and
            sent.EDI_REC_TYPE_CD = otbnd.EDI_REC_TYPE_CD
        where
            otbnd.EDI_REC_TYPE_CD = '862'
            and otbnd.ITEM_NO = ?
            and otbnd.LOC = ?
            and otbnd.REQ_DATE = ?
    )
    select 
        CAL_DATE, 
        case 
            when CAL_DATE = ? then '---REQ_DATE---' 
            when WEEKEND then 'WEEKEND'  
            else '' 
            end as EVENT, 
        EDI_DATE, 
        ARCV_TS, 
        ITEM_NO, 
        LOC, VNDR_ID, 
        REQ_DATE, 
        REQ_QTY
    from ML_PREDICT_SR.UTIL_DATES
    left outer join d
    on ARCV_TS+1 = CAL_DATE
    where CAL_DATE >= (select min(ARCV_TS+1) from d)
    and CAL_DATE <= max((select max(ARCV_TS+1) from d), ?)
    order by CAL_DATE desc
    """
    return blu.fetch(sql, [item_no, loc, req_date, req_date, req_date])
 
def fetch_EDI_changes(item_no, loc, req_date, formula_col):
    sql="""
    select 
        mpv.ITEM_NO,
        mpv.LOC,
        mpv.VNDR_ID,
        mpv.REQ_DATE,
        mpv.EDI_DATE,
        mpv.OLD_QTY,
        mpv.MTCH_QTY,
        mpv.NEW_QTY,
        delt.SCORE_PRE_SUM,
        delt.F_DAYS_OUT,
        delt.F_PERCENT_CHANGE,
        delt.DAYS_OUT,
        mpv.EDI_RSN_CD,
        mpv.COMTS1_60,
        mpv.COMTS2_60
    from ML_PREDICT_SR.CLONE_MPVNEDIC mpv
    left outer join ML_PREDICT_SR.SUMRY_EDI_DELTA_CALC_LIST delt
    on mpv.ITEM_NO = delt.ITEM_NO
    and mpv.LOC = delt.LOC
    and mpv.REQ_DATE = delt.REQ_DATE
    and mpv.EDI_DATE = delt.EDI_DATE
    where mpv.ITEM_NO=? and mpv.LOC=? and mpv.REQ_DATE=? 
    order by mpv.EDI_DATE desc
    """
    return blu.fetch(sql, [item_no, loc, req_date])

def plot_ts(df, x_name, y_name, x_tooltip_name=None, y_tooltip_name=None, title=None):
    x_tooltip_name = x_tooltip_name or x_name
    y_tooltip_name = y_tooltip_name or y_name
    p = figure(x_axis_type='datetime', 
               plot_width=800, 
               plot_height=400,
               tools='xwheel_zoom,box_zoom,pan,reset,hover,save',
               y_range=(-0.02, 1.02))
    p.toolbar.active_scroll = p.select_one(WheelZoomTool) 
    p.title.text = title or '{y} by {x}'.format(x=x_name, y=y_name)
    p.title.align = 'center'
    p.xaxis.axis_label = x_name
    p.yaxis.axis_label = y_name
    p.line(x=x_name, 
           y=y_name, 
           line_width=1, 
           color='firebrick',
           source=ColumnDataSource(df))
    p.scatter(x=x_name, 
              y=y_name, 
              size=8, 
              color='firebrick', 
              fill_color='white', 
              source=ColumnDataSource(df))
    p.select(dict(type=HoverTool)).tooltips = [(x_name,'@%s' % x_tooltip_name), 
                                               (y_name,'@%s' % y_tooltip_name)]
    return p
    
def plot_part_instab(item_no, loc, formula_col):
    sql = """
    select REQ_DATE, ORDER_EDI_INSTABILITY_POSITIVE_ONLY
    from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES 
    where ITEM_NO=? and LOC=? 
    order by REQ_DATE
    """
    g_data = blu.fetch(sql, [item_no, loc])
    
    instability_col = 'ORDER_EDI_INSTABILITY_POSITIVE_ONLY'.format(formula_col)

    g_data['x_tool'] = [x.strftime("%Y-%m-%d") for x in g_data['REQ_DATE']]
    g_data['y_tool'] = g_data[instability_col].round(2)

    p = plot_ts(df=g_data, 
                x_name='REQ_DATE', 
                y_name=instability_col,
                x_tooltip_name='x_tool', 
                y_tooltip_name='y_tool',
                title='{itm} instability at {loc}'.format(itm=item_no, loc=loc))
    
    return p, g_data

@server.route('/instability/')
def main_empty():
    return render_template('instability.html', formula='cuberoot')
    
@server.route('/instability/', methods=['POST'])
def main_submit():  
    user_item_nos = request.form.get('user_item_nos')
    if user_item_nos is not None:
        if ',' in user_item_nos:
            user_item_nos = user_item_nos.split(',')
        elif len(user_item_nos) > 0:
            user_item_nos = [user_item_nos]
        else:
            user_item_nos = []
    
    which_tool = request.form.get('submit')
    item_no = request.form.get('item_no')
    loc = request.form.get('loc')
    req_date = request.form.get('req_date')
    formula = request.form.get('formula_family') or 'cuberoot'
    if formula:
        formula_col = {'exponential': '_EXPONENTIAL',
                       'linear': '_LINEAR',
                       'piecewise': '_PIECEWISE',
                       'logistic': '_LOGISTIC',
                       'cuberoot': ''}[formula]
    else:
        formula_col = ''
        
    print("\t{}\n\t{}\n\t{}\n\t{}\n\t{}".format(item_no, loc, req_date, formula, user_item_nos))
    
    payload = {}
    
    if which_tool == 'plot_stab' and item_no and loc:
        plot, g_data = plot_part_instab(item_no, loc, formula_col)
        script, div = components(plot)
        payload = {'div': div, 
                   'script': script}
                   
    elif which_tool == 'fetch_delta' and item_no and loc and req_date:    
        data = fetch_EDI_changes(item_no, loc, req_date, formula_col)
        payload = {'have_dataframe': True, 
                   'dataframe': data.to_html(),
                   'table_download_function': 'download_EDI_changes'}
        
    elif which_tool == 'fetch_raw' and item_no and loc and req_date:
        data = fetch_EDIs(item_no, loc, req_date)
        payload = {'have_dataframe': True,
                   'dataframe': data.to_html(),
                   'table_download_function': 'download_EDIs'}

    return render_template('instability.html', selected_item_no=item_no,
                                         selected_loc=loc,
                                         selected_date=req_date,
                                         formula=formula,
                                         user_item_nos=user_item_nos,
                                         **payload)
    
@server.route('/item_nos/', endpoint='get_ITEM_NOs')
#@cached()
def get_ITEM_NOs():
    sql="""
    select ITEM_NO, count(1) as COUNT 
    from ML_PREDICT_SR.CLONE_MPVNEDIC 
    where EDI_REC_TYPE_CD = '862' 
    group by ITEM_NO  
    order by COUNT desc 
    fetch first 50 rows only
    """
    df = blu.fetch(sql, [])
    return jsonify({'ITEM_NOs': df['ITEM_NO'].str.strip().tolist()})

@server.route('/locs_for/<string:item_no>/', endpoint='get_LOCs')
#@cached()
def get_LOCs(item_no):
    sql="""
    select LOC
    from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES
    where ITEM_NO=?
    group by LOC 
    order by LOC
    """
    df = blu.fetch(sql, [item_no])
    return jsonify({'LOCs': df['LOC'].tolist()})
    
@server.route('/dates_for/<string:item_no>/<string:loc>/', endpoint='get_REQ_DATEs')
#@cached()
def get_REQ_DATEs(item_no, loc):
    sql="""
    select REQ_DATE
    from ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES 
    where ITEM_NO=? and LOC=?
    group by REQ_DATE 
    order by REQ_DATE desc
    """
    df = blu.fetch(sql, [item_no, loc])
    return jsonify({'REQ_DATEs': pd.to_datetime(df['REQ_DATE']).dt.strftime('%Y-%m-%d').tolist(),
                    'SQL': sql.replace('\n', ' '),
                    'SQL_args': [item_no, loc]})

@server.route('/validate_item_no/<string:item_no>/', endpoint='get_ITEM_NO_VALID')
#@cached()
def get_ITEM_NO_valid(item_no):
    sql="""
    SELECT   ITEM_NO
    FROM     ML_PREDICT_SR.SUMRY_EDI_ORDER_SCORES 
    where    ITEM_NO = ?
    fetch first 1 row only
    """
    item_no_list = blu.fetch(sql, [item_no])['ITEM_NO'].tolist()
    item_no_list = [x.strip() for x in item_no_list]
    
    return jsonify({'is_ITEM_NO': item_no in item_no_list,
                    'ITEM_NO': item_no})

@server.route('/instability/excel/<string:action>/', endpoint='get_Excel')
#cached()
def get_Excel(action):
    item_no = request.args.get('item')
    req_date = request.args.get('date')
    loc = request.args.get('loc')
    
    output = BytesIO()
    writer = pd.ExcelWriter(output, engine='xlsxwriter')
    wb = writer.book
    vert = wb.add_format()
    vert.set_rotation(90)
    vert.set_bold()
    vert.set_align('center')
    vert.set_align('bottom')
    vert.set_border(1)
    
    columns = []
    to_rotate = []
    if action == "EDIs":
        filename = "EDIs for {} at {} on {}".format(item_no, loc, req_date)
        columns = [('A:A', 12),
                   ('B:B', 15),
                   ('C:C', 12),
                   ('D:E', 18),
                   ('F:F', 4),
                   ('G:I', 12)]
        df = fetch_EDIs(item_no, loc, req_date)
    elif action == "EDIchanges":
        filename = "EDI Changes for {} at {} on {}".format(item_no, loc, req_date)
        columns = [('A:A', 18),
                   ('B:B', 4),
                   ('C:H', 12),
                   ('I:I', 16),
                   ('J:J', 12),
                   ('K:K', 20),
                   ('L:M', 12),
                   ('N:O', 40)]
        df = fetch_EDI_changes(item_no, loc, req_date, '')
    elif action == "order_summary":
        filename = "Order summary for {} at {} on {}".format(item_no, loc, req_date)
        columns = [('A:A', 18),
                   ('B:B', 4),
                   ('C:C', 18),
                   ('D:Y', 3),
                   ('Z:Z', 18),
                   ('AA:AA', 12),
                   ('AB:AB', 18),
                   ('AC:AC', 12),
                   ('AD:AD', 4),
                   ('AE:AF', 18),
                   ('AG:AG', 11),
                   ('AH:AK', 16),
                   ('AL:AL', 10),
                   ('AM:AN', 14.5)]
        df = fetch_order_summary(item_no, loc, req_date)
        to_rotate = [(i, v) for i,v in enumerate(df.columns.values) if 'BIN_' in v]
    else:
        filename = "undefined"
        df = pd.DataFrame()
    
    df.to_excel(writer, index=False, sheet_name='Sheet1')
    
    for col, width in columns:
        writer.sheets['Sheet1'].set_column(col, width)
    
    for i, v in to_rotate:
        writer.sheets['Sheet1'].write(0, i, v, vert)
    
    
    writer.save()    
    writer.close()
    output.seek(0)
    
    return send_file(output, attachment_filename=filename+".xlsx", as_attachment=True)
                    
@server.after_request
def add_header(response):
    # response.cache_control.no_store = True
    if 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'no-store,no-cache'
    return response